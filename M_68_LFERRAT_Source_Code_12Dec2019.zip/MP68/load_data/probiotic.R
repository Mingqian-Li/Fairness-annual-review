# load mp68_formula_probiotics_masked

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

library(readxl)
probiotics <- read_excel(paste0(dataPath,"mp68_formula_probiotics_masked.xlsx"))
