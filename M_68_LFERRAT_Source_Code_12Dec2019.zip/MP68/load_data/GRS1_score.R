#############################################################
## Create combined GRS1
## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################


############################## 
# 1 - Source file 
##############################

dataPathGRS1 <- dataPath
dataFilenonHLA <- "GRS1_nonHLA.profile"
nonHLAScore <- read.csv(paste0(dataPathGRS1,dataFilenonHLA), sep = "")
##############################
# 2 - Compute grs1 score
##############################

demographics <- demographics %>%
  mutate(HLAscore_grs1 = case_when(
    HLA_Category_all == "0" ~ 0, #X/X
    HLA_Category_all == "1" ~ 3.87, # DR4-DR3
    HLA_Category_all == "2" ~ 3.09, # DR4-DR4
    HLA_Category_all == "3" ~ 1.95, #DR4-X
    HLA_Category_all == "4" ~ 1.95, #DR4-X
    HLA_Category_all == "5" ~ 1.95, #DR4-X
    HLA_Category_all == "6" ~ 1.95, #DR4-X
    HLA_Category_all == "7" ~ 1.95, #DR4-X
    HLA_Category_all == "8" ~ 1.95, #DR4-X
    HLA_Category_all == "9" ~ 3.05, #DR3-DR3
    HLA_Category_all == "10" ~ 1.51 #DR3-X
  )) %>%
  left_join(nonHLAScore, by = c("MP68_MaskID" = "IID")) %>%
  mutate(grs1 = SCORESUM + HLAscore_grs1) %>%
  # filter(!is.na(grs1)) %>%
  mutate(grs1sntile = ntile(grs1,4)) %>%
  mutate(grs1strat = case_when(
    grs1sntile == 1 ~ "low",
    (grs1sntile == 2 | grs1sntile == 3) ~ "medium",
    TRUE ~ "hight"),
    grs1strat2 = if_else(grs1sntile == 1 | grs1sntile == 2 | grs1sntile == 3,"low","hight")) %>%
  mutate(grs1strat = factor(grs1strat),
         grs1strat2 = factor(grs1strat2))

