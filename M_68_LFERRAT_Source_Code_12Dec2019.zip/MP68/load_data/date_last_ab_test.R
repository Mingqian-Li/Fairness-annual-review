library(ggplot2)
library(dplyr)
library(tidyr)
library(forcats) 
library(readxl)
ab_date <- read_excel(paste0(dataPath,"mp68_ab_titers_masked.xlsx"))

date_last_test <- ab_date %>% 
  mutate(last_test = ref_visit) %>%
  group_by(MP68_MaskID) %>%
  top_n(1,ref_visit) %>%
 # top(-1,ref_visit) %>%
  ungroup() %>%
  select(MP68_MaskID,last_test)
  
          

