# load mp68_rie_gie_inf_totals_masked

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

library(readxl)
rie_gie_inf <- read_excel(paste0(dataPath,"mp68_rie_gie_inf_totals_masked.xlsx"))
