# load mp68_fg_gluten_masked

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

library(readxl)
gluten <- read_excel(paste0(dataPath,"mp68_fg_gluten_masked.xlsx"))
