# extract day vitamin_c

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

vitamin_c_day <- vitamin_c %>% 
          filter( due_num == 12) %>%
          select(MP68_MaskID, vitamin_c_mg_l)
                    
