# extract day probiotics

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

# probiotics_day <- probiotics %>% 
#   mutate(probio_category = case_when(
#     formstart_dy_1 <31 ~ "before1m",
#     formstart_dy_1 <365.25 ~ "after1m",
#     formstart_dy_1 <300000 ~ "after1Y",
#     TRUE ~ "never"  )) %>%
#   mutate(probio = if_else(formstart_dy_1 < day,probio_category,"unknown")) %>%
#   mutate(probio = (ifelse(is.na(probio),"unknown",probio)),
#          probio = factor(probio)) %>%
#   select(probio,MP68_MaskID)

# probiotics_day <- probiotics %>% 
#   mutate(probio_category = case_when(
#     first_startagew <5 ~ "before1m",
#     first_startagew <52 ~ "after1m",
#     first_startagew <300000 ~ "after1Y",
#     TRUE ~ "never"  )) %>%
#   mutate(probio = if_else(first_startagew < day/7,probio_category,"unknown")) %>%
#   mutate(probio = (ifelse(is.na(probio),"unknown",probio)),
#          probio = factor(probio)) %>%
#   select(probio,MP68_MaskID)

probiotics_day <- probiotics %>% 
  mutate(probio = if_else(is.na(probiotics_before_4w),0,1),
         probio = factor(probio)) %>%
  select(probio,MP68_MaskID)
