# extract day respiratory

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

respiratory_day <- respiratory %>% filter( illness_agemos*30.5 < day) %>%
                    group_by(MP68_MaskID) %>%
                    summarise( fevergrp_tot_day = sum(fevergrp, na.rm = TRUE),
                               common_cold_tot_day = sum(common_cold, na.rm = TRUE),
                               laryngitis_trac_tot_day = sum(laryngitis_tracheitis, na.rm = TRUE),
                               influenza_tot_day = sum(influenza, na.rm = TRUE),
                               acute_sinusitis = sum(acute_sinusitis, na.rm = TRUE)) %>%
                    replace_na(list(fevergrp_tot_day = 0,
                                    common_cold_tot_day = 0,
                                    laryngitis_trac_tot_day = 0,
                                    influenza_tot_day = 0,
                                    acute_sinusitis = 0)) %>% 
                    mutate(all_infection = fevergrp_tot_day + common_cold_tot_day + laryngitis_trac_tot_day + influenza_tot_day + acute_sinusitis) %>% 
                    ungroup()
  
