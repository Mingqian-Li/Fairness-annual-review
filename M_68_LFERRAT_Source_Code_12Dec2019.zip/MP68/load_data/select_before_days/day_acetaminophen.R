# extract day acetaminophen

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

acetaminophen_day <- acetaminophen %>% filter( medage_in_months*30.5 < day) %>%
                      group_by(MP68_MaskID) %>%
                      summarise(totdrug = sum(numdays)) %>%
                      ungroup()

