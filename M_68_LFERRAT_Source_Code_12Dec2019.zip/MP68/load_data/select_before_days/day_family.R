# extract day family

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################



daysfam <- ifelse(day < 40000,40000,day)
family_up <- family %>%
  group_by(MP68_MaskID) %>%
  filter(fam_hist_agedys < daysfam) %>%
  top_n(-1,fam_hist_agedys) %>%
  ungroup()
familysibling <- family_up %>%
  group_by(MP68_MaskID) %>%
  filter(fam_hist_agedys < daysfam) %>%
  top_n(1,fam_hist_agedys) %>%
  gather(key,value,Sibling1DiabetesType,Sibling2DiabetesType,Sibling3DiabetesType,Sibling4DiabetesType,Sibling5DiabetesType,Sibling6DiabetesType,Sibling7DiabetesType) %>%
  summarise(siblingsDiabetesType = ifelse(any(value == "Type 1",na.rm = TRUE),"yes","no")) %>%
  ungroup()
family_day <- family_up %>% left_join(familysibling,by = c("MP68_MaskID")) %>%
  select(MP68_MaskID, siblingsDiabetesType, FatherDiabetesType, MotherDiabetesType)

