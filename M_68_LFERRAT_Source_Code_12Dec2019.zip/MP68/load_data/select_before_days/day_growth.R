# extract day growth

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################


# daysgrowth <- day
# daymin <- day - 3*30.5
# daymax <- day + 3*30.5


# growth_day  <- growth %>%
#   filter( daymin < DUE_NUM*30.5 & DUE_NUM*30.5 < daymax) %>%
#   mutate(bmiz2 = rowMeans(cbind(imp_bmiz, bmiz), na.rm = TRUE),
#          bmiz2 = rowMeans(cbind(imp_bmiz, bmiz), na.rm = TRUE),
#          weight2 = rowMeans(cbind(imp_weight, weight), na.rm = TRUE)) %>%
#   group_by(MP68_MaskID) %>%
#   summarise(imputed_min_bmiz = min(bmiz2,na.rm = TRUE),
#             imputed_mean_bmiz = mean(bmiz2 ,na.rm = TRUE),
#             weight = mean(weight2 ,na.rm = TRUE)) %>%
#   mutate(imputed_min_bmiz = ifelse(imputed_min_bmiz == Inf, NA, imputed_min_bmiz),
#          imputed_mean_bmiz = ifelse(imputed_mean_bmiz == Inf, NA, imputed_mean_bmiz)) %>%
#   ungroup()


#selec weight at year 1 

growth_day <-  growth %>% 
                filter( 11 < DUE_NUM & DUE_NUM < 13) %>%
                mutate( weight = imp_weight)