# extract day ab

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

ab_day <- ab %>% 
  mutate(
    persist_conf_gad_all_time = persist_conf_gad,
    persist_conf_ia2a_all_time = persist_conf_ia2a,
    persist_conf_miaa_all_time = persist_conf_miaa,
  multiple_autoantibody_all_time = if_else(persist_conf_gad_all_time + persist_conf_ia2a_all_time + persist_conf_miaa_all_time > 1 ,1 , 0),
  multiple_autoantibody_all_time = factor(multiple_autoantibody_all_time),
  any_autoantibody_all_time = if_else(persist_conf_gad_all_time + persist_conf_ia2a_all_time + persist_conf_miaa_all_time > 0 ,1 , 0),
  persist_conf_gad = if_else((persist_conf_gad_agemos * 30.5) > day, 0, persist_conf_gad),
  persist_conf_gad = if_else(is.na(persist_conf_gad),0,persist_conf_gad),
  persist_conf_ia2a = if_else((persist_conf_ia2a_agemos * 30.5) > day, 0, persist_conf_ia2a),
  persist_conf_ia2a = if_else(is.na(persist_conf_ia2a),0, persist_conf_ia2a),
  persist_conf_miaa = if_else((persist_conf_miaa_agemos * 30.5) > day, 0, persist_conf_miaa),
  persist_conf_miaa = if_else(is.na(persist_conf_miaa),0, persist_conf_miaa),
    multiple_autoantibody = if_else(persist_conf_gad + persist_conf_ia2a + persist_conf_miaa > 1 ,1 , 0),
  multiple_autoantibody = factor(multiple_autoantibody),
  number_autoantibody = (persist_conf_gad + persist_conf_ia2a + persist_conf_miaa),
  #number_autoantibody = if_else(number_autoantibody == 3,2, number_autoantibody),
  number_autoantibody = factor(number_autoantibody)) %>%
  mutate( # create two groups of autoantibody onset, early and late
    persist_conf_gadclass = if_else(((persist_conf_gad_agemos * 30.5) < day) & ((persist_conf_gad_agemos * 30.5) > (2 * 365.25)), 2, persist_conf_gad),
    persist_conf_gadclass = if_else(is.na(persist_conf_gadclass),0,persist_conf_gadclass),
    persist_conf_ia2aclass = if_else(((persist_conf_ia2a_agemos * 30.5) < day) & ((persist_conf_ia2a_agemos * 30.5) > (2 * 365.25)), 2, persist_conf_ia2a),
    persist_conf_ia2aclass = if_else(is.na(persist_conf_ia2aclass),0,persist_conf_ia2aclass),
    persist_conf_miaaclass = if_else(((persist_conf_miaa_agemos * 30.5) < day) & ((persist_conf_miaa_agemos * 30.5) > (2 * 365.25)), 2, persist_conf_miaa),
    persist_conf_miaaclass = if_else(is.na(persist_conf_miaaclass),0,persist_conf_miaaclass)) %>%
  select(MP68_MaskID, persist_conf_gad, persist_conf_ia2a, persist_conf_miaa,persist_conf_gadclass, persist_conf_ia2aclass, persist_conf_miaaclass,multiple_autoantibody, persist_conf_gad_all_time,persist_conf_ia2a_all_time,persist_conf_miaa_all_time,multiple_autoantibody_all_time,any_autoantibody_all_time,number_autoantibody)
