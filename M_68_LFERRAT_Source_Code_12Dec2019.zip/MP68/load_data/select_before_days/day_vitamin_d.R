# extract day vitamin_d

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

vitamin_d_day <- vitamin_d %>% 
                filter(due_num == 12) %>%
                select(MP68_MaskID,vitd_nmo_l)