# extract day rie_gie_inf

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

rie_gie_inf_day <- rie_gie_inf %>% filter( due_num*30.5 <= day) %>%
                    group_by(MP68_MaskID) %>%
                    summarise( resp_tot_day = sum(resp_tot),
                    gastro_tot_day = sum(gastro_tot))

