# Extract information known before #days#

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################



demographics_up <- demographics 
# %>%
#   filter((last_clinic_visit_agedys + 6*31) > day) %>% # to capture people who are diagnosed with t1d just after their last visit
#   filter(t1d == 0 | !(t1d_diag_agedys < day ))

demographics_day <- demographics_up %>%
  mutate( positive_all_time = positive,
          persist_conf_ab_all_time = persist_conf_ab,
          positive = ifelse(persist_conf_agedys > day, 0, positive),
         persist_conf_ab = ifelse(persist_conf_agedys > day | is.na(persist_conf_agedys),0,persist_conf_ab))
