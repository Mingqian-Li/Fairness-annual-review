# imputation 
#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

finaldata <- finaldata %>% mutate_if(is.numeric,funs(replace(., which(is.na(.)), median(., na.rm = TRUE))))
