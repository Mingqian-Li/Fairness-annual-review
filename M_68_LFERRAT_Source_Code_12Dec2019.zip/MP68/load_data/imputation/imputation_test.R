# imputation test
#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################
library(mice)
library(VIM)
library(missForest)
############################## 
# 1 - Source file 
##############################
summary(finaldata)
data <- finaldata[,c("fathers_age","resp_gest_inf","start_daycare_yr1","fevergrp_tot_day","common_cold_tot_day","laryngitis_trac_tot_day","influenza_tot_day","acute_sinusitis","resp_tot_day","gastro_tot_day")]
md.pattern(data)

aggr_plot <- aggr(data, col = c('navyblue','red'), numbers = TRUE, sortVars = TRUE, labels = names(data), cex.axis = .7, gap = 3, ylab = c("Histogram of missing data","Pattern"))

#keep column with less than 10% missing values
finaldata.mis <- finaldata %>% select(which(colMeans(is.na(.)) < 0.5)) 
# remove non informative column
finaldata.mis <- finaldata.mis %>% select(sex,cc,country_cd,maternal_age,fathers_age,c_section,resp_gest_inf,race_ethnicity,hla_category,fdr,maternal,start_daycare_yr1,grs1,siblingsDiabetesType,FatherDiabetesType,MotherDiabetesType,probio)
#impute missing values, using all parameters as default values
 finaldata.imp <- missForest(finaldata.mis)
 
 
 imputed <- mice(finaldata.mis,m = 5,maxit = 50,meth = 'pmm',seed = 500)
 summary(imputed)
 imputed <- complete(imputed)
 
