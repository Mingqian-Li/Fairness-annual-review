# load mp68_GRS

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################


GRS2 <- read.csv(paste0(dataPath,"grs2_full.txt"), sep = "")
GRS2 <- GRS2 %>% mutate(MP68_MaskID = IID, GRS2 = grs2_full) %>% 
              select(MP68_MaskID,GRS2)
