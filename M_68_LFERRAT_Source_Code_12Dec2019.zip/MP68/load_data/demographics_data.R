# main load

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

library(readxl)
demographics <- read_excel(paste0(dataPath,"mp68_demographics_masked.xlsx"))
                                       