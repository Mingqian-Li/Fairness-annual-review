# load mp68_growth_masked

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

library(readxl)
growth <- read_excel(paste0(dataPath,"mp68_growth_masked.xlsx"))
