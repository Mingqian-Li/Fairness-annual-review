# load mp68_respiratory_infections_mask

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

library(readxl)
respiratory <- read_excel(paste0(dataPath,"mp68_respiratory_infections_mask.xlsx"))
