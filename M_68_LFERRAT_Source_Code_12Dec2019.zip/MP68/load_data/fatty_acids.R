# load mp68_fatty_acids_masked

#############################################################
## ## ferratlauric@gmail.com - September 2018
#############################################################

##############################
# 0 - Load librairies
##############################

############################## 
# 1 - Source file 
##############################

library(readxl)
fatty_acids <- read_excel(paste0(dataPath,"mp68_fatty_acids_masked.xlsx"))
