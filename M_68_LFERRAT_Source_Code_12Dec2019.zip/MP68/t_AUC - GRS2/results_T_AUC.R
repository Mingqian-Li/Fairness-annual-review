##### templatenalyse results t_AUC
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################
# library to load
library(timeROC)
library(survival)
library(caret)
source('C:/Users/Lauric/Desktop/Postdoc/PCA/SEARCH/ggplotAUC.R')

method <- "Cox"
# method <- "gbm"
complexity <- "abn_grs_fdr"
# complexity <- "abn_grs_fdr_weight"
# complexity <- "full_model_1"
# complexity <- "very_simple"
day_beginv <- c(60,365.25,365.25 + 183,365.25*2 + seq(0,5*365.25,365))
day_endv <- c(365.25,365.25*3,5*365.25,8*365.25)

n_time_begin <- length(day_beginv)
n_time_end <- length(day_endv)
AUC_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
seAUC_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
for (i in 1:n_time_begin) {
  for (j in 1:n_time_end) {
    day_begin = day_beginv[i]
    day_end =  day_beginv[i] + day_endv[j]
names_tAUC <- paste0("t_AUC_",method,"_complexity_",complexity,"_day_begin_",day_begin,"_day_end_",day_end)
load(file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/",names_tAUC,".RData"))
# extract relevant information
# ROC.T$AUC[2] -> AUC
# ROC.t$inference$vect_sd_1 -> sd of AUC


# save results
AUC_m[i,j] <- ROC.T$AUC[2]
seAUC_m[i,j] <- ROC.T$inference$vect_sd_1[2]
#remove object to clear memory space
# rm(list = names_tAUC)

  }
}
prediction_at <-  c("8 weeks","1 year","18 months","2 years","3 years","4 years","5 years","6 years","7 years")
prediction_for <- c("1 year","3 years","5 years","8 years")

row.names(AUC_m) <- prediction_at 
colnames(AUC_m) <- prediction_for


confup <- create_IC_se(AUC_m,seAUC_m,confidencev = 1.96, class = "up")
conflow <- create_IC_se(AUC_m,seAUC_m,confidencev = 1.96, class = "low")



ggplotAUC2(AUC_m,conflow, confup,prediction_at ,names_var = "future")
ggsave(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC/figures/t_AUC_",method,"_",complexity,".jpg"),width = 9.6,height = 8.52)


save(list = c("AUC_m","confup","conflow","seAUC_m"),file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC/figures/t_AUC_",method,"_",complexity,".Rdata"))


library(cowplot)
prediction_at <-  c(0.5,1,1.5,2,seq(3,7))
prediction_for <- c(1,3,5,8,10,12)
rownames(AUC_m) <- prediction_at 
colnames(AUC_m) <- prediction_for

data_plot <- AUC_m %>% data.frame()
data_plot <- data_plot %>% mutate(time_from = row.names(data_plot))
data_plot <- data_plot %>% gather(key = "years",value = "t_AUC",X1,X3,X5) %>% 
    select(-c("X8","X10","X12"))
data_plot$time_from <- as.numeric(data_plot$time_from)
data_plot$years <- factor(data_plot$years)
ggplot(data_plot, aes(x = time_from, y = t_AUC,group = years, colour = years)) +
  geom_line(size = 1.5) + 
  xlab("prediction from years") + 
  ylab("time AUC") +
  scale_x_continuous(breaks = seq(0,7)) +
  ylim(c(0,1)) +
  scale_colour_discrete(name = "Prediction to",
                        labels = c("1 year","3 years","5 years")) +
  theme_bw()


library(cowplot)
prediction_at <-  c(0.5,1,1.5,2,seq(3,7))
prediction_for <- c(1,3,5,8,10,12)
rownames(AUC_m) <- prediction_at 
colnames(AUC_m) <- prediction_for

data_plot <- AUC_m %>% data.frame()
data_plot <- data_plot %>% mutate(time_from = row.names(data_plot))
data_plot <- data_plot %>% gather(key = "years",value = "t_AUC",X1,X3,X5,X8)
data_plot$time_from <- as.numeric(data_plot$time_from)

ggplot(data_plot, aes(x = time_from, y = t_AUC,colour = factor(years))) +
  geom_line(size = 1.5) + 
  xlab("landmark times (years)") + 
  ylab("time AUC") +
  scale_x_continuous(breaks = seq(0,7)) +
  scale_y_continuous(breaks = seq(0,1,0.1),limits = c(0,1)) +
  scale_colour_discrete(name = "horizon times",
                        breaks = c("X1","X3","X5","X8","X10","X12"),
                        labels = c("1 year","3 years","5 years","8 years","10 years","12 years")) +
  ggtitle("Fig 1. Time-dependent AUC in the Teddy database for\n several values of landmark times and horizon times") + 
  theme_bw() +
  theme(axis.text = element_text(size = 14),
        axis.title = element_text(size = 14),
        legend.position = c(0.8, 0.5),
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14))

ggsave(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC/figures/t_AUC_plot",method,"_",complexity,".jpg"))
