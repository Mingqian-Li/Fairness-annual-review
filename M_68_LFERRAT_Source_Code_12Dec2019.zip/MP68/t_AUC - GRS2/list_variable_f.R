#############################################################
## list_variable for ml
## ferratlauric@gmail.com - Decembre 2018
#############################################################


############################## 
# 1 - function
##############################

list_variable_f <- function(day,complexity){
  list_variable <- complexity
  if (complexity == "all") {
    if (day < 1) {
     list_variable <- c("Sex","country_cd","c_section","race_ethnicity","maternal","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","fathers_age","maternal_age","resp_gest_inf","weight")
      
    }
    if (day > 1 & day < 365.25) {
     list_variable <- c("Sex","country_cd","c_section","race_ethnicity","maternal","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","fathers_age","maternal_age","resp_gest_inf","fevergrp_tot_day","common_cold_tot_day","laryngitis_trac_tot_day","influenza_tot_day","acute_sinusitis","resp_tot_day","gastro_tot_day","weight")
    }
    if (day >= 365.25 & day <= 365.25*2) {
     list_variable <- c("Sex","country_cd","c_section","race_ethnicity","maternal","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","fathers_age","maternal_age","resp_gest_inf","fevergrp_tot_day","common_cold_tot_day","laryngitis_trac_tot_day","influenza_tot_day","acute_sinusitis","resp_tot_day","gastro_tot_day","vitd_nmo_l","vitamin_c_mg_l","weight")
    }
    if (day >= 365.25*2) {
     list_variable <- c("Sex","country_cd","c_section","race_ethnicity","maternal","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","fathers_age","maternal_age","resp_gest_inf","fevergrp_tot_day","common_cold_tot_day","laryngitis_trac_tot_day","influenza_tot_day","acute_sinusitis","resp_tot_day","gastro_tot_day","vitd_nmo_l","vitamin_c_mg_l","imputed_mean_bmiz","weight")
    }
    if (day >= 365.25*5) {
     list_variable <- c("Sex","country_cd","c_section","race_ethnicity","maternal","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","fathers_age","maternal_age","resp_gest_inf","fevergrp_tot_day","common_cold_tot_day","laryngitis_trac_tot_day","influenza_tot_day","acute_sinusitis","resp_tot_day","gastro_tot_day","vitd_nmo_l","vitamin_c_mg_l","imputed_mean_bmiz","weight")
    }
  }
  #######################################
  if (complexity == "simple") {
    if (day < 1) {
     list_variable <- c("country_cd","maternal","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","weight")
      
    }
    if (day > 1 & day < 365.25) {
     list_variable <- c("country_cd","maternal","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","weight","probio")
    }
    if (day >= 365.25 & day <= 365.25*2) {
     list_variable <- c("country_cd","maternal","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","acute_sinusitis","vitd_nmo_l","vitamin_c_mg_l","weight")
    }
    if (day >= 365.25*2) {
     list_variable <- c("country_cd","maternal","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","acute_sinusitis","vitd_nmo_l","vitamin_c_mg_l","weight")
    }
  }
  ######################################
  if (complexity == "ab") {
    if (day < 200) {
     list_variable <- c("1")
      
    }
    if (day > 200 ) {
     list_variable <- c("1","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa")
      #list_variable <- c("gad_agetest_cat","miaa_agetest_cat","ia2a_agetest_cat")
    }
    
  }
  if (complexity == "simple_access") {
    if (day < 1) {
     list_variable <- c("country_cd","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","weight")
      
    }
    if (day > 1 & day < 365.25) {
     list_variable <- c("country_cd","probio","maternal","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","acute_sinusitis","weight")
    }
    if (day >= 365.25 & day <= 365.25*2) {
     list_variable <- c("country_cd","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","acute_sinusitis","vitd_nmo_l","vitamin_c_mg_l","weight")
    }
    if (day >= 365.25*2) {
     list_variable <- c("country_cd","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","acute_sinusitis","vitd_nmo_l","vitamin_c_mg_l","weight")
    }
  }
  if (complexity == "without_autoantibody") {
    if (day < 1) {
     list_variable <- c("country_cd","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","weight")
      
    }
    if (day > 1 & day < 365.25) {
     list_variable <- c("country_cd","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","acute_sinusitis","weight")
    }
    if (day >= 365.25 & day <= 365.25*2) {
     list_variable <- c("country_cd","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","acute_sinusitis","vitd_nmo_l","vitamin_c_mg_l","weight")
    }
    if (day >= 365.25*2) {
     list_variable <- c("country_cd","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","acute_sinusitis","vitd_nmo_l","vitamin_c_mg_l","weight")
    }
  }
  if (complexity == "without_autoantibody") {
    if (day < 1) {
      list_variable <- c("country_cd","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","weight")
      
    }
    if (day > 1 & day < 365.25) {
      list_variable <- c("country_cd","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","acute_sinusitis","weight")
    }
    if (day >= 365.25 & day <= 365.25*2) {
      list_variable <- c("country_cd","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","acute_sinusitis","vitd_nmo_l","vitamin_c_mg_l","weight")
    }
    if (day >= 365.25*2) {
      list_variable <- c("country_cd","probio","siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType","GRS2","acute_sinusitis","vitd_nmo_l","vitamin_c_mg_l","weight")
    }
  }
    if (complexity == "very_simple") {
      if (day < 1) {
        list_variable <- c("country_cd","fdr","GRS2","weight")
        }
      if (day > 1 & day < 365.25) {
        list_variable <- c("country_cd","probio","fdr","GRS2","weight","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa")
      }
      if (day >= 365.25 & day <= 365.25*2) {
        list_variable <- c("country_cd","probio","fdr","GRS2","weight","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa")
      }
      if (day >= 365.25*2) {
        list_variable <- c("country_cd","probio","fdr","GRS2","weight","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa")
      }
    }
  if (complexity == "abn") {
    if (day < 200) {
      list_variable <- c("1")
      
    }
    if (day > 200 ) {
      list_variable <- c("1","number_autoantibody")
      #list_variable <- c("gad_agetest_cat","miaa_agetest_cat","ia2a_agetest_cat")
    }
    
  }
  if (complexity == "abn_grs") {
    if (day < 200) {
      list_variable <- c("1","GRS2")
      
    }
    if (day > 200 ) {
      list_variable <- c("1","GRS2","number_autoantibody")
      #list_variable <- c("gad_agetest_cat","miaa_agetest_cat","ia2a_agetest_cat")
    }
    
  }
  if (complexity == "abn_grs") {
    if (day < 200) {
      list_variable <- c("GRS2")
      
    }
    if (day > 200 ) {
      list_variable <- c("GRS2","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa")
      #list_variable <- c("gad_agetest_cat","miaa_agetest_cat","ia2a_agetest_cat")
    }
    
  }
  if (complexity == "ab_grs_fdr") {
    if (day < 200) {
      list_variable <- c("GRS2","fdr")
      
    }
    if (day > 200 ) {
      list_variable <- c("GRS2","fdr","persist_conf_gad","persist_conf_ia2a","persist_conf_miaa")
      #list_variable <- c("gad_agetest_cat","miaa_agetest_cat","ia2a_agetest_cat")
    }
    
  }
  if (complexity == "abn_grs_fdr") {
    if (day < 200) {
      list_variable <- c("GRS2","fdr")
      
    }
    if (day > 200 ) {
      list_variable <- c("GRS2","fdr","number_autoantibody")
    }
    
  }
  if (complexity == "abn_grs_fdr_mab") {
    if (day < 200) {
      list_variable <- c("GRS2","fdr","maternal")
      
    }
    if (day > 200 ) {
      list_variable <- c("GRS2","fdr","number_autoantibody","maternal")
    }
    
  }
  if (complexity == "abn_grs_fdr_weight") {
    if (day < 200) {
      list_variable <- c("GRS2","fdr","weight")
      
    }
    if (day > 200 ) {
      list_variable <- c("GRS2","fdr","number_autoantibody","weight")
    }
    
  }
  if (complexity == "grs") {
      list_variable <- c("GRS2")
  }
  if (complexity == "grs1") {
    list_variable <- c("grs1")
  }
  
  if (complexity == "grs_fdr") {
    if (day < 200) {
      list_variable <- c("GRS2","fdr")
      
    }
    if (day > 200 ) {
      list_variable <- c("GRS2","fdr")
    }
    
  }
  if (complexity == "abn_fdr") {
    if (day < 200) {
      list_variable <- c("fdr")
      
    }
    if (day > 200 ) {
      list_variable <- c("number_autoantibody","fdr")
    }
    
  }
  if (complexity == "full_model_1") {
    if (day <= 360 ) {
      list_variable <- c("GRS2","fdr","weight","probio","maternal","fathers_age","maternal_age","resp_gest_inf")
      
    }
    if (day > 360 ) {
      list_variable <- c("GRS2","fdr","number_autoantibody","weight","probio","acute_sinusitis","maternal","fathers_age","maternal_age","resp_gest_inf")
    }
    
  }
  if (complexity == "abn_grs_c_section") {
    if (day <= 360 ) {
      list_variable <- c("GRS2","c_section")
      
    }
    if (day > 360 ) {
      list_variable <- c("GRS2","c_section","number_autoantibody")
    }
    
  }
  if (complexity == "full_model_pvalue") {
    if (day <= 360 ) {
      list_variable <- c("GRS2","fdr","weight")
      
    }
    if (day > 360 ) {
      list_variable <- c("GRS2","fdr","number_autoantibody","weight","country_cd","acute_sinusitis")
    }
    
  }
  if (complexity == "fdr") {
    if (day <= 360 ) {
      list_variable <- c("fdr")
      
    }
    if (day > 360 ) {
      list_variable <- c("fdr")
    }
    
  }
  if (complexity == "weighted_fdr") {
    if (day <= 360 ) {
      list_variable <- c("siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType")
      
    }
    if (day > 360 ) {
      list_variable <- c("siblingsDiabetesType","FatherDiabetesType","MotherDiabetesType")
    }
    
  }
  if (complexity == "all_ABn") {
    if (day < 1) {
      list_variable <- c("Sex","country_cd","c_section","race_ethnicity","maternal","fdr","GRS2","fathers_age","maternal_age","resp_gest_inf","weight")
      
    }
    if (day > 1 & day < 365.25) {
      list_variable <- c("Sex","country_cd","c_section","race_ethnicity","maternal","number_autoantibody","probio","fdr","GRS2","fathers_age","maternal_age","resp_gest_inf","fevergrp_tot_day","common_cold_tot_day","laryngitis_trac_tot_day","influenza_tot_day","acute_sinusitis","resp_tot_day","gastro_tot_day","weight")
    }
    if (day >= 365.25 & day <= 365.25*2) {
      list_variable <- c("Sex","country_cd","c_section","race_ethnicity","maternal","number_autoantibody","probio","fdr","GRS2","fathers_age","maternal_age","resp_gest_inf","fevergrp_tot_day","common_cold_tot_day","laryngitis_trac_tot_day","influenza_tot_day","acute_sinusitis","resp_tot_day","gastro_tot_day","weight")
    }
    if (day >= 365.25*2) {
      list_variable <- c("Sex","country_cd","c_section","race_ethnicity","maternal","number_autoantibody","probio","fdr","GRS2","fathers_age","maternal_age","resp_gest_inf","fevergrp_tot_day","common_cold_tot_day","laryngitis_trac_tot_day","influenza_tot_day","acute_sinusitis","resp_tot_day","gastro_tot_day","weight")
    }
    if (day >= 365.25*5) {
      list_variable <- c("Sex","country_cd","c_section","race_ethnicity","maternal","number_autoantibody","probio","fdr","GRS2","fathers_age","maternal_age","resp_gest_inf","fevergrp_tot_day","common_cold_tot_day","laryngitis_trac_tot_day","influenza_tot_day","acute_sinusitis","resp_tot_day","gastro_tot_day","weight")
    }
  }
  return(list_variable)
    }