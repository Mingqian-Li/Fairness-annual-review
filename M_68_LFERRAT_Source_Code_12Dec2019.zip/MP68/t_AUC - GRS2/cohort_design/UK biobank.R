library(readr)
library(ggplot2)

table_UKB <- read.delim("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/figures/ROC_table_UKB.txt")

table_UKB[which.min(abs(table_UKB$sensitivity-0.75)),]
table_UKB[which.min(abs(table_UKB$sensitivity-0.80)),]
table_UKB[which.min(abs(table_UKB$sensitivity-0.85)),]
table_UKB[which.min(abs(table_UKB$sensitivity-0.90)),]
table_UKB[which.min(abs(table_UKB$sensitivity-0.95)),]
table_UKB[which.min(abs(table_UKB$sensitivity-0.99)),]


ggplot(table_UKB,aes(x = sensitivity, y = centile)) +
  geom_line()

seq(0.8,1,0.05)*0.9

sensitivity_initial <- c(table_UKB[which.min(abs(table_UKB$sensitivity-0.7)),"sensitivity"],table_UKB[which.min(abs(table_UKB$sensitivity-0.75)),"sensitivity"],table_UKB[which.min(abs(table_UKB$sensitivity-0.80)),"sensitivity"],table_UKB[which.min(abs(table_UKB$sensitivity-0.85)),"sensitivity"],table_UKB[which.min(abs(table_UKB$sensitivity-0.90)),"sensitivity"],table_UKB[which.min(abs(table_UKB$sensitivity-0.95)),"sensitivity"],table_UKB[which.min(abs(table_UKB$sensitivity-0.99)),"sensitivity"])
population_initial <- 1 - c(table_UKB[which.min(abs(table_UKB$sensitivity-0.7)),"centile"],table_UKB[which.min(abs(table_UKB$sensitivity-0.75)),"centile"],table_UKB[which.min(abs(table_UKB$sensitivity-0.80)),"centile"],table_UKB[which.min(abs(table_UKB$sensitivity-0.85)),"centile"],table_UKB[which.min(abs(table_UKB$sensitivity-0.90)),"centile"],table_UKB[which.min(abs(table_UKB$sensitivity-0.95)),"centile"],table_UKB[which.min(abs(table_UKB$sensitivity-0.99)),"centile"])

sensitivity_cohort <-  c(1,0.71,0.86,0.9,0.92,0.96,0.84,0.86,0.9,0.92,0.96)
n_visit <- c(18,6.1,8.9,9.8,10.4,12.3,6.59,7.37,8.18,10.6,13.45)

data.frame(sensitivity_cohort, n_visit)

cohort <- rep(c("A",rep("B",5),rep("C",5)),length(sensitivity_initial))
sensitivity_population <- c(sensitivity_cohort %o% sensitivity_initial)
total_visit <- c(n_visit %o% population_initial)

data_cohort <- data.frame(cohort,sensitivity_population,total_visit)

ggplot(data_cohort, aes(x = sensitivity_population, y = total_visit, colour = cohort)) +
  geom_point() + 
  xlim(c(0.7,1))


cohort <- c("A",rep("B",4),rep("C",5))
sensitivity_cohort <-  c(1,0.86,0.9,0.92,0.96,0.84,0.86,0.9,0.92,0.96)
n_visit <- c(18,8.9,9.8,10.4,12.3,6.59,7.37,8.18,10.6,13.45)

population_initial_80 <- c()
sensitivity_n <- 0.75
for (i in sensitivity_cohort) {
  y <- sensitivity_n/i
  population_initial_80 <- c(population_initial_80,1 - c(table_UKB[which.min(abs(table_UKB$sensitivity - y)),"centile"]))
}
total_visit_80 <- c(n_visit * population_initial_80)
total_visit_80_ratio_cases <- total_visit_80/(sensitivity_n*0.005)

data_cohort <- data.frame(cohort,population_initial_80,total_visit_80,sensitivity_cohort,total_visit_80_ratio_cases,n_visit)

p <- ggplot(data_cohort, aes(x = population_initial_80, y = total_visit_80, colour = cohort, group = sensitivity_cohort,group_2 = total_visit_80_ratio_cases,group_3 = n_visit)) +
  geom_point()

ggplotly(p)

