##### adaptive cohort t-AUC
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################
# library to load

set.seed(123)

# clean from previous figure
day <- 0
dayend = Inf
source(paste0(codePath,"Extract_information_per_date.R"))
source(paste0(codePath,"/t_AUC - GRS2/function_T_AUC.R"))
source(paste0(codePath,"/t_AUC - GRS2/list_variable_f.R"))


method <- "Cox"
complexity <- "abn_grs_fdr"
day_beginv2 <- c(60,365.25,365.25*2,1095.5, 1460.5 + seq(0*365.25,4*365.25,2*365),3650) + 45

n_time_begin <- length(day_beginv2)
individuals_to_keep <- finaldata$MP68_MaskID
caugh <- rep(0,n_time_begin)
missed <- rep(0,n_time_begin)
visit <- rep(0,n_time_begin)
IDmissed <- c()
IDcaugh <- c()
ratio_kept_people2 <- 1
for (i in 1:(n_time_begin - 1)) {
  day <- day_beginv2[i]
  dayend = Inf
  source(paste0(codePath,"Extract_information_per_date.R"))
  dataset_ml <- finaldata
  individuals_to_keep <- finaldata$MP68_MaskID
  individuals_to_keep <- individuals_to_keep[individuals_to_keep != 566432] # remove this person because of no good follow up
  # if (i > 1 ) {
    #load Cox model
    names_tAUC <- paste0("Cox_model_","_complexity_",complexity,"_day_begin_",day)
    load(file = paste0(pathSaveModels,names_tAUC,".RData"))
    
    # #create score Cox model
    # score <- predict(res.cox, dataset_ml, type = "risk")
    #create score Cox model
    lp.pred <- predict(res.cox, dataset_ml, type = "lp")
    # Baseline Function
    base <- basehaz(res.cox)
    
    base_time <- base[ which.min(abs(base$time - (day + 2*365.25))),"hazard"]
    #https://stats.stackexchange.com/questions/288393/calculating-survival-probability-per-person-at-time-t-from-cox-ph
    Pred.val_1 <- 1 - exp(-base_time[1])^exp(lp.pred)
    print(quantile(Pred.val_1))
    #remove people from survey/ update individuals_to_keep
    # individuals_to_keep <- dataset_ml[score > quantile(score,quantilev[i - 1]),"MP68_MaskID"]
    
    individuals_to_keepnew <- dataset_ml[Pred.val_1 > 0.008,"MP68_MaskID"]
    individuals_to_follow_passively <- dataset_ml[Pred.val_1 <= 0.008,"MP68_MaskID"]
    ratio_kept_people2[i] <- length( individuals_to_keepnew) / length(individuals_to_keep)
    individuals_to_keep <- individuals_to_keepnew
    visit[i] <- round((day_beginv2[i + 1] - day_beginv2[i])/365.25*2)/2 * length(individuals_to_keepnew)*count_visit_active(1,day_beginv2[i]/365.25) + round((day_beginv2[i + 1] - day_beginv2[i])/365.25*2)/2 * length(individuals_to_follow_passively)*count_visit_passive(1, round(day/365.25))
    caugh[i] <- sum(as.numeric(dataset_ml[dataset_ml$MP68_MaskID %in% individuals_to_keep & dataset_ml$t1d_diag_agedys < day_beginv2[i + 1] & dataset_ml$t1d_diag_agedys > day_beginv2[i],"t1d"]) - 1)
    missed[i] <- sum(as.numeric(dataset_ml[!(dataset_ml$MP68_MaskID %in% individuals_to_keep) & dataset_ml$t1d_diag_agedys < day_beginv2[i + 1] & dataset_ml$t1d_diag_agedys > day_beginv2[i],"t1d"]) - 1)
  IDmissed <- c(IDmissed,dataset_ml[!(dataset_ml$MP68_MaskID %in% individuals_to_keep) & dataset_ml$t1d_diag_agedys < day_beginv2[i + 1] & as.numeric(dataset_ml$t1d) == 2,"MP68_MaskID"])
  IDcaugh <- c(IDcaugh,dataset_ml[dataset_ml$MP68_MaskID %in% individuals_to_keep & dataset_ml$t1d == 1 & dataset_ml$t1d_diag_agedys < day_beginv2[i + 1],"MP68_MaskID"])
  }
cumulativevisit <- cumsum(visit)
cumulativemissed <- cumsum(missed)
cumulativecaugh <- cumsum(caugh)
print(length(individuals_to_keep))
print(sum(caugh))
print(sum(missed))
print(caugh)
print(missed)
ratio_caught <- caugh/(caugh + missed)
m2 <- data.frame(round(day_beginv2*2/365.25)/2,round(caugh),missed,ratio_caught*100,c(ratio_kept_people2,NA)*100,cumulativecaugh,cumulativemissed,cumulativevisit)
m2 <- m2[-c(n_time_begin),]

print(m2)
print(sum(caugh)/(sum(missed) + sum(caugh)))
  
################################
############### save dataframe on word #################
################################
table_summary <- m2
colnames(table_summary) <- c("landmark/horizon","T1D children caught", "T1D children missed ","proportion of T1D caugh per period","proportion of people in the cohort","cumulative caugh","cumulative missed","cumulative visites")

myft <- regulartable(
  table_summary)
myft
myft <- theme_vanilla(myft)
myft


doc <- read_docx()
doc <- body_add_flextable(doc, value = myft)
print(doc, target = paste0(pathfigures_tables,"tableS5C.docx"))

