source('C:/Users/Lauric/Dropbox/PostdocTeddy/t_AUC/adaptative_cohort.R')


data[data$MP68_MaskID %in% IDmissed,]


test <- survfit(res.cox,dataset_ml)
head(test)


summary(test)$time
summary(test)$surv
