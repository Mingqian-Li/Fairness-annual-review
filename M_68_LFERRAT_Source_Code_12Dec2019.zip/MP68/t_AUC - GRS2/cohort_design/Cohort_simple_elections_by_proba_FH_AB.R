##### main t-AUC
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################
# library to load
library(timeROC)
library(survival)
library(caret)
library(flextable)
library(officer)
set.seed(123)



method <- "Cox"

complexity <- "abn_fdr"
day_beginv1 <- c(0,365.25,365.25 * 2,1095.5,1460.5,1825.5,2190.5,2555.5,2920.5,3650) + 45
proba_simple <- seq(0.001,0.015,0.001)
sensitivity_cohort_simple <- rep(0,length(proba_simple))
n_visit_simple <- rep(0,length(proba_simple))
for (p in 1:length(proba_simple)) {
  day <- 0
  dayend = Inf
  source(paste0(codePath,"Extract_information_per_date.R"))
  n_time_begin <- length(day_beginv1)
  individuals_to_keep <- finaldata$MP68_MaskID
  caugh <- rep(0,n_time_begin)
  missed <- rep(0,n_time_begin)
  IDmissed <- c()
  IDcaugh <- c()
  visit <- rep(0,n_time_begin)
  ratio_kept_people1 <- 1
  cumulativevisit <- rep(0,length(day_beginv1))
  for (i in 1:(n_time_begin - 1)) {
    day <- day_beginv1[i]
    dayend = Inf
    source(paste0(codePath,"Extract_information_per_date.R"))
    dataset_ml <- finaldata[finaldata$MP68_MaskID %in% individuals_to_keep,]
    individuals_to_keep <- dataset_ml$MP68_MaskID # to study the ratio on only the people who did not drop out the study
    if (i > 1 ) {
      #load Cox model
      names_tAUC <- paste0("Cox_model_","_complexity_",complexity,"_day_begin_",day)
      load(file = paste0(pathSaveModels,names_tAUC,".RData"))
      
      # #create score Cox model
      # score <- predict(res.cox, dataset_ml, type = "risk")
      #create score Cox model
      lp.pred <- predict(res.cox, dataset_ml, type = "lp")
      # Baseline Function
      base <- basehaz(res.cox)
      
      base_time <- base[ which.min(abs(base$time - (10*365.25))),"hazard"]
      #https://stats.stackexchange.com/questions/288393/calculating-survival-proba_simplebility-per-person-at-time-t-from-cox-ph
      Pred.val_1 <- 1 - exp(-base_time[1])^exp(lp.pred)
      # print(quantile(Pred.val_1))
      #remove people from survey/ update individuals_to_keep
      # individuals_to_keep <- dataset_ml[score > quantile(score,quantilev[i - 1]),"MP68_MaskID"]
      
      individuals_to_keepnew <- dataset_ml[Pred.val_1 > proba_simple[p],"MP68_MaskID"]
      ratio_kept_people1[i] <- ratio_kept_people1[i - 1] *  length( individuals_to_keepnew) / length(individuals_to_keep)
      individuals_to_keep <- individuals_to_keepnew
    }
    visit[i] <- round((day_beginv1[i + 1] - day_beginv1[i])/365.25*2)/2 * length(individuals_to_keep)*count_visit_active(1,day_beginv1[i]/365.25)
    caugh[i] <- sum(as.numeric(dataset_ml[dataset_ml$MP68_MaskID %in% individuals_to_keep & dataset_ml$t1d_diag_agedys <= day_beginv1[i + 1] & dataset_ml$t1d_diag_agedys > day_beginv1[i],"t1d"]) - 1)
    missed[i] <- sum(as.numeric(dataset_ml[!(dataset_ml$MP68_MaskID %in% individuals_to_keep) & dataset_ml$t1d_diag_agedys <= day_beginv1[length(day_beginv1)] ,"t1d"]) - 1)
    IDmissed2 <- c(IDmissed,dataset_ml[!(dataset_ml$MP68_MaskID %in% individuals_to_keep) & dataset_ml$t1d == 1 & dataset_ml$t1d_diag_agedys < day_beginv1[i + 1],"MP68_MaskID"])
    IDcaugh2 <- c(IDcaugh,dataset_ml[dataset_ml$MP68_MaskID %in% individuals_to_keep & dataset_ml$t1d == 1 & dataset_ml$t1d_diag_agedys < day_beginv1[i + 1],"MP68_MaskID"])
  }
  
  cumulativemissed <- cumsum(missed)
  cumulativevisit <- cumsum(visit)
  cumulativecaught <- cumsum(caugh)
  # print(day_beginv1)
  # print(length(individuals_to_keep))
  # print(caugh)
  # print(missed)
  ratio_caught <- caugh/(caugh + missed)
  m1 <-  data.frame(round(day_beginv1*2/365.25)/2,caugh,missed,ratio_caught,c(1,ratio_kept_people1),cumulativemissed,cumulativecaught,cumulativevisit)
  m1 <- m1[-c(n_time_begin),]
  # print(m1)
  print(sum(caugh)/(sum(missed) + sum(caugh)))
  # print(ratio_kept_people1)
  
  quantilev <- ratio_kept_people1
  day_beginv <- day_beginv1 
  # count <- count_visit_cohort1(year_v = day_beginv,p_v = quantilev)
  # print(count)
  print(quantilev)
  res1 <- median_visit_cohort1(year_v = day_beginv,p_v = quantilev)
  mean(res1)
  median(res1)
  
  sensitivity_cohort_simple[p] <- sum(caugh)/(sum(missed) + sum(caugh))
  n_visit_simple[p] <- mean(res1)
}
print(sensitivity_cohort_simple)
print(n_visit_simple)
save(sensitivity_cohort_simple,n_visit_simple,proba_simple,file = paste0(pathSaveModels,complexity,"cohort_selection_proba_simple.Rdata"))

