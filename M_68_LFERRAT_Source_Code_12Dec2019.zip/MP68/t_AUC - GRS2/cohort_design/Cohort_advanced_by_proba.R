##### adaptive cohort t-AUC
#############################################################
## ## ferratlauric@gmail.com - May 2019
#############################################################


set.seed(123)


count_visit_active <- function(p_active,year){
  n_visit <- case_when(
    year < 1  ~ p_active * 1,
    year < 3  ~ p_active * 4,
    year < 6 ~ p_active * 2,
    year < 8 ~ p_active,
    TRUE ~ p_active/2)
  return(n_visit)
}

count_visit_passive <- function(p_passive,year){
  n_visit <- case_when(
    year < 4  ~ p_passive,
    TRUE ~ p_passive/2)
  return(n_visit)
}

count_visit_cohort1 <- function(year_v,p_v){
  n <- length(year_v)
  n_visit_active <- 0
  n_visit_passive <- 0
  p_in <- 1
  for (i in 1:(n - 1)) {
    p_in <- p_in * p_v[i]
    n_visit_active <- n_visit_active + round((year_v[i + 1] - year_v[i])/365.25) * count_visit_active(p_in,round(year_v[i]/365.25))
    n_visit_passive <- n_visit_passive + round((year_v[i + 1] - year_v[i])/365.25) * count_visit_passive(1 - p_in,round(year_v[i]/365.25))
    print(count_visit_active(p_in,year_v[i]))
  }
  result <- data.frame(n_visit_active,n_visit_passive)
  return(result)
}

count_visit_cohort2 <- function(year_v,p_v){
  n <- length(year_v)
  n_visit_active <- 0
  n_visit_passive <- 0
  p_in <- 1
  for (i in 1:(n - 1)) {
    p_in <- p_v[i]
    n_visit_active <- n_visit_active + round((year_v[i + 1] - year_v[i])/365.25) * count_visit_active(p_in,round(year_v[i]/365.25))
    n_visit_passive <- n_visit_passive + count_visit_passive(1 - p_in,round(year_v[i]/365.25))
  }
  result <- data.frame(n_visit_active,n_visit_passive)
  return(result)
}

median_visit_cohort1 <- function(year_v,p_v){
  n <- length(year_v)
  p_in <- 1
  median_vect <- rep(0,10000)
  for (i in 1:(n - 1)) {
    p_in <- p_v[i]
    n_visit_active <-  count_visit_active(1,round(year_v[i]/365.25)) * round((year_v[i + 1] - year_v[i])/365.25*2)/2
    print(n_visit_active )
    print(count_visit_active(p_in,year_v[i]/365.25))
    median_vect[1:round(p_in * 10000)] <- median_vect[1:round(p_in * 10000)] + n_visit_active 
  }
  result <- median_vect
  return(result)
}

median_visit_cohort2 <- function(year_v,p_v){
  n <- length(year_v)
  p_in <- 1
  median_vect <- rep(0,10000)
  for (i in 1:(n - 1)) {
    p_in <- p_v[i]
    n_visit_active <-  count_visit_active(1,round(year_v[i]/365.25)) * round((year_v[i + 1] - year_v[i])*2/365.25)/2
    
    print(n_visit_active )
    print(year_v[i])
    n_visit_passive <- count_visit_passive(1,round(year_v[i]/365.25)) * round((year_v[i + 1] - year_v[i])/365.25)
    
    median_vect[1:round(p_in * 10000)] <- median_vect[1:round(p_in * 10000)] + n_visit_active 
    if (round(p_in * 10000) < 10000) {
      median_vect[(1 + round(p_in * 10000)):10000] <- median_vect[(1 + round(p_in * 10000)):10000] + n_visit_passive
    }
  }
  result <- median_vect #add 1 for last visits at 10 years
  return(result)
}


method <- "Cox"
# complexity <- "full_model_1"
complexity <- "abn_grs_fdr"
day_beginv2 <- c(60,365.25,365.25*2,1095.5, 1460.5 + seq(0*365.25,4*365.25,2*365),3650) + 45
proba_advanced <- seq(0.001,0.02,0.001)
sensitivity_cohort_advanced <- rep(0,length(proba_advanced))
n_visit_advanced <- rep(0,length(proba_advanced))
for(p in 1:length(proba_advanced)){
n_time_begin <- length(day_beginv2)
individuals_to_keep <- finaldata$MP68_MaskID
caugh <- rep(0,n_time_begin)
missed <- rep(0,n_time_begin)
visit <- rep(0,n_time_begin)
IDmissed <- c()
IDcaugh <- c()
ratio_kept_people2 <- 1
for (i in 1:(n_time_begin - 1)) {
  day <- day_beginv2[i]
  dayend = Inf
  source(paste0(codePath,"Extract_information_per_date.R"))
  dataset_ml <- finaldata
  individuals_to_keep <- finaldata$MP68_MaskID
  individuals_to_keep <- individuals_to_keep[individuals_to_keep != 566432] # remove this person because of no good follow up
  # if (i > 1 ) {
  #load Cox model
  names_tAUC <- paste0("Cox_model_","_complexity_",complexity,"_day_begin_",day)
  load(file = paste0(pathSaveModels,names_tAUC,".RData"))
  
  # #create score Cox model
  # score <- predict(res.cox, dataset_ml, type = "risk")
  #create score Cox model
  lp.pred <- predict(res.cox, dataset_ml, type = "lp")
  # Baseline Function
  base <- basehaz(res.cox)
  
  base_time <- base[ which.min(abs(base$time - (day + 2*365.25))),"hazard"]
  #https://stats.stackexchange.com/questions/288393/calculating-survival-proba_advancedbility-per-person-at-time-t-from-cox-ph
  Pred.val_1 <- 1 - exp(-base_time[1])^exp(lp.pred)
  print(quantile(Pred.val_1))
  #remove people from survey/ update individuals_to_keep
  # individuals_to_keep <- dataset_ml[score > quantile(score,quantilev[i - 1]),"MP68_MaskID"]
  
  individuals_to_keepnew <- dataset_ml[Pred.val_1 > proba_advanced[p],"MP68_MaskID"]
  individuals_to_follow_passively <- dataset_ml[Pred.val_1 <= proba_advanced[p],"MP68_MaskID"]
  ratio_kept_people2[i] <- length( individuals_to_keepnew) / length(individuals_to_keep)
  individuals_to_keep <- individuals_to_keepnew
  visit[i] <- round((day_beginv2[i + 1] - day_beginv2[i])/365.25*2)/2 * length(individuals_to_keepnew)*count_visit_active(1,day_beginv2[i]/365.25) + round((day_beginv2[i + 1] - day_beginv2[i])/365.25*2)/2 * length(individuals_to_follow_passively)*count_visit_passive(1, round(day/365.25))
  caugh[i] <- sum(as.numeric(dataset_ml[dataset_ml$MP68_MaskID %in% individuals_to_keep & dataset_ml$t1d_diag_agedys < day_beginv2[i + 1] & dataset_ml$t1d_diag_agedys > day_beginv2[i],"t1d"]) - 1)
  missed[i] <- sum(as.numeric(dataset_ml[!(dataset_ml$MP68_MaskID %in% individuals_to_keep) & dataset_ml$t1d_diag_agedys < day_beginv2[i + 1] & dataset_ml$t1d_diag_agedys > day_beginv2[i],"t1d"]) - 1)
  IDmissed <- c(IDmissed,dataset_ml[!(dataset_ml$MP68_MaskID %in% individuals_to_keep) & dataset_ml$t1d_diag_agedys < day_beginv2[i + 1] & as.numeric(dataset_ml$t1d) == 2,"MP68_MaskID"])
  IDcaugh <- c(IDcaugh,dataset_ml[dataset_ml$MP68_MaskID %in% individuals_to_keep & dataset_ml$t1d == 1 & dataset_ml$t1d_diag_agedys < day_beginv2[i + 1],"MP68_MaskID"])
}
cumulativevisit <- cumsum(visit)
cumulativecaught <- cumsum(caugh)
cumulativemissed <- cumsum(missed)
print(length(individuals_to_keep))
print(sum(caugh))
print(sum(missed))
print(caugh)
print(missed)
ratio_caught <- caugh/(caugh + missed)
m2 <- data.frame(round(day_beginv2*2/365.25)/2,caugh,missed,ratio_caught,c(1,ratio_kept_people2),cumulativemissed,cumulativecaught,cumulativevisit)
m2 <- m2[-c(n_time_begin),]

print(m2)
print(sum(caugh)/(sum(missed) + sum(caugh)))

day_beginv <- day_beginv2
quantilev <- ratio_kept_people2
count <- count_visit_cohort2(year_v = day_beginv,p_v = quantilev)
print(count)
res2 <- median_visit_cohort2(year_v = day_beginv,p_v = quantilev)
mean(res2)
median(res2)
sensitivity_cohort_advanced[p] <- sum(caugh)/(sum(missed) + sum(caugh))
n_visit_advanced[p] <- mean(res2)
}

save(sensitivity_cohort_advanced,n_visit_advanced,proba_advanced,file = paste0(pathSaveModels,"cohort_advanced_proba_advanced.Rdata"))
