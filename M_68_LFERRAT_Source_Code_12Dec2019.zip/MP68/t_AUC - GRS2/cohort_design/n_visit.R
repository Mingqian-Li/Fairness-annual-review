#####  count number of 
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################


# count_visit_active <- function(p_active,year){
#  n_visit <- case_when(
#    year < 1  ~ p_active * 3,
#    year < 2  ~ p_active * 4,
#    year < 4 ~ p_active * 2,
#    TRUE ~ p_active)
# return(n_visit)
# }
# 
# count_visit_passive <- function(p_passive){
#   n_visit <- p_passive
#   return(n_visit)
# }
count_visit_active <- function(p_active,year){
  n_visit <- case_when(
    year < 1  ~ p_active * 1,
    year < 3  ~ p_active * 4,
    year < 6 ~ p_active * 2,
    year < 8 ~ p_active,
    year < 9 ~ p_active/2,
    TRUE ~ 0)
  return(n_visit)
}

count_visit_passive <- function(p_passive,year){
  n_visit <- case_when(
    year < 4  ~ p_passive,
  year <8 ~ p_passive/2,
  TRUE ~ 0)
  return(n_visit)
}

count_visit_cohort1 <- function(year_v,p_v){
  n <- length(year_v)
  n_visit_active <- 0
  n_visit_passive <- 0
  p_in <- 1
  for (i in 1:(n - 1)) {
    p_in <- p_in * p_v[i]
    n_visit_active <- n_visit_active + round((year_v[i + 1] - year_v[i])/365.25) * count_visit_active(p_in,round(year_v[i]/365.25))
    n_visit_passive <- n_visit_passive + round((year_v[i + 1] - year_v[i])/365.25) * count_visit_passive(1 - p_in,round(year_v[i]/365.25))
  print(count_visit_active(p_in,year_v[i]))
     }
  result <- data.frame(n_visit_active,n_visit_passive)
  return(result)
}

count_visit_cohort2 <- function(year_v,p_v){
  n <- length(year_v)
  n_visit_active <- 0
  n_visit_passive <- 0
  p_in <- 1
  for (i in 1:(n - 1)) {
    p_in <- p_v[i]
    n_visit_active <- n_visit_active + round((year_v[i + 1] - year_v[i])/365.25) * count_visit_active(p_in,round(year_v[i]/365.25))
    n_visit_passive <- n_visit_passive + count_visit_passive(1 - p_in,round(year_v[i]/365.25))
  }
  result <- data.frame(n_visit_active,n_visit_passive)
  return(result)
}

median_visit_cohort1 <- function(year_v,p_v){
  n <- length(year_v)
  p_in <- 1
  median_vect <- rep(0,10000)
  for (i in 1:(n - 1)) {
    p_in <- p_v[i]
    n_visit_active <-  count_visit_active(1,round(year_v[i]/365.25)) * round((year_v[i + 1] - year_v[i])/365.25*2)/2
    # print(n_visit_active )
    # print(count_visit_active(p_in,year_v[i]/365.25))
    median_vect[1:round(p_in * 10000)] <- median_vect[1:round(p_in * 10000)] + n_visit_active 
    }
  result <- median_vect
  return(result)
}

median_visit_cohort2 <- function(year_v,p_v){
  n <- length(year_v)
  p_in <- 1
  median_vect <- rep(0,10000)
  for (i in 1:(n - 1)) {
    p_in <- p_v[i]
    n_visit_active <-  count_visit_active(1,round(year_v[i]/365.25)) * round((year_v[i + 1] - year_v[i])*2/365.25)/2

    # print(n_visit_active )
     # print(year_v[i])
    n_visit_passive <- count_visit_passive(1,round(year_v[i]/365.25)) * round((year_v[i + 1] - year_v[i])/365.25)
    
    median_vect[1:round(p_in * 10000)] <- median_vect[1:round(p_in * 10000)] + n_visit_active 
    if (round(p_in * 10000) < 10000) {
    median_vect[(1 + round(p_in * 10000)):10000] <- median_vect[(1 + round(p_in * 10000)):10000] + n_visit_passive
    }
  }
  result <- median_vect #add 1 for last visits at 10 years
  return(result)
}

### normal
day_beginv <- seq(0,3652.5,365.25)
quantilev <- rep(1,11)
count <- count_visit_cohort1(year_v = day_beginv,p_v = quantilev)
print(count)

res <- median_visit_cohort1(year_v = day_beginv,p_v = quantilev)
mean(res)
median(res)

### progress from simple adaptative

quantilev <- ratio_kept_people1
day_beginv <- day_beginv1 
count <- count_visit_cohort1(year_v = day_beginv,p_v = quantilev)
print(count)
res1 <- median_visit_cohort1(year_v = day_beginv,p_v = quantilev)
mean(res1)
median(res1)
plot(res1)
### progress from advanced adaptative
day_beginv <- day_beginv2
quantilev <- ratio_kept_people2
count <- count_visit_cohort2(year_v = day_beginv,p_v = quantilev)
print(count)
res2 <- median_visit_cohort2(year_v = day_beginv,p_v = quantilev)
mean(res2)
median(res2)
plot(res2)
