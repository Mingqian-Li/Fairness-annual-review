##### main t-AUC
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################

set.seed(123)

# clean from previous figure
day <- 0
dayend = Inf
source(paste0(codePath,"Extract_information_per_date.R"))
source(paste0(codePath,"/t_AUC - GRS2/function_T_AUC.R"))
source(paste0(codePath,"/t_AUC - GRS2/list_variable_f.R"))

count_visit_active <- function(p_active,year){
  n_visit <- case_when(
    year < 1  ~ p_active * 1,
    year < 3  ~ p_active * 4,
    year < 6 ~ p_active * 2,
    year < 8 ~ p_active,
    TRUE ~ p_active/2)
  return(n_visit)
}
method <- "Cox"
complexity <- "abn_grs_fdr"
day_beginv1 <- c(0,365.25,365.25 * 2,1095.5,1460.5,1825.5,2190.5,2555.5,2920.5,3650) + 45

n_time_begin <- length(day_beginv1)
individuals_to_keep <- finaldata$MP68_MaskID
caugh <- rep(0,n_time_begin)
missed <- rep(0,n_time_begin)
IDmissed <- c()
IDcaugh <- c()
visit <- rep(0,n_time_begin)
ratio_kept_people1 <- 1
for (i in 1:(n_time_begin - 1)) {
  day <- day_beginv1[i]
  dayend = Inf
  source(paste0(codePath,"Extract_information_per_date.R"))
  dataset_ml <- finaldata[finaldata$MP68_MaskID %in% individuals_to_keep,]
  individuals_to_keep <- dataset_ml$MP68_MaskID # to study the ratio on only the people who did not drop out the study
  if (i > 1 ) {
    #load Cox model
    names_tAUC <- paste0("Cox_model_","_complexity_",complexity,"_day_begin_",day)
    load(file = paste0(pathSaveModels,names_tAUC,".RData"))
    
    # #create score Cox model
    # score <- predict(res.cox, dataset_ml, type = "risk")
    #create score Cox model
    lp.pred <- predict(res.cox, dataset_ml, type = "lp")
    # Baseline Function
    base <- basehaz(res.cox)
    
    base_time <- base[ which.min(abs(base$time - (10*365.25))),"hazard"]
    #https://stats.stackexchange.com/questions/288393/calculating-survival-probability-per-person-at-time-t-from-cox-ph
    Pred.val_1 <- 1 - exp(-base_time[1])^exp(lp.pred)
    
    #remove people from survey/ update individuals_to_keep
    # individuals_to_keep <- dataset_ml[score > quantile(score,quantilev[i - 1]),"MP68_MaskID"]
    
    individuals_to_keepnew <- dataset_ml[Pred.val_1 > 0.006,"MP68_MaskID"]
    print(length( individuals_to_keepnew) / length(individuals_to_keep))
    ratio_kept_people1[i] <- ratio_kept_people1[i - 1] *  length( individuals_to_keepnew) / length(individuals_to_keep)
    individuals_to_keep <- individuals_to_keepnew
    }
  visit[i] <- round((day_beginv1[i + 1] - day_beginv1[i])/365.25*2)/2 * length(individuals_to_keep)*count_visit_active(1,day_beginv1[i]/365.25)
  caugh[i] <- sum(as.numeric(dataset_ml[dataset_ml$MP68_MaskID %in% individuals_to_keep & dataset_ml$t1d_diag_agedys <= day_beginv1[i + 1] & dataset_ml$t1d_diag_agedys > day_beginv1[i],"t1d"]) - 1)
  missed[i] <- sum(as.numeric(dataset_ml[!(dataset_ml$MP68_MaskID %in% individuals_to_keep) & dataset_ml$t1d_diag_agedys <= day_beginv1[length(day_beginv1)] ,"t1d"]) - 1)
  IDmissed2 <- c(IDmissed,dataset_ml[!(dataset_ml$MP68_MaskID %in% individuals_to_keep) & dataset_ml$t1d == 1 & dataset_ml$t1d_diag_agedys < day_beginv1[i + 1],"MP68_MaskID"])
  IDcaugh2 <- c(IDcaugh,dataset_ml[dataset_ml$MP68_MaskID %in% individuals_to_keep & dataset_ml$t1d == 1 & dataset_ml$t1d_diag_agedys < day_beginv1[i + 1],"MP68_MaskID"])
}

cumulativemissed <- cumsum(missed)
cumulativevisit <- cumsum(visit)
cumulativecaugh <- cumsum(caugh)
print(day_beginv1)
print(length(individuals_to_keep))
print(caugh)
print(missed)
ratio_caught <- caugh/(caugh + missed)
m1 <-  data.frame(round(day_beginv1*2/365.25)/2,caugh,missed,ratio_caught*100,c(ratio_kept_people1,NA)*100,cumulativecaugh,cumulativemissed,cumulativevisit)
m1 <- m1[-c(n_time_begin),]
print(m1)
print(sum(caugh)/(sum(missed) + sum(caugh)))
print(ratio_kept_people1)
# to identify patients who disapear...

################################
############### save dataframe on word #################
################################
table_summary <- m1
colnames(table_summary) <- c("landmark","T1D children caught", "T1D children missed ","proportion of T1D caugh per year","proportion of people in the cohort","cumulative caugh","cumulative missed","cumulative visites")

myft <- regulartable(
  table_summary)
myft
myft <- theme_vanilla(myft)
myft


doc <- read_docx()
doc <- body_add_flextable(doc, value = myft)
print(doc, target = paste0(pathfigures_tables,"Table5B.docx"))

