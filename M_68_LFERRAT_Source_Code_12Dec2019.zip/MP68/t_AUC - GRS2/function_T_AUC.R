# pipeline functions

#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################
# library to load

tAUC_ml <- function(method,complexity,dataset_ml,dataset_timedep,day_begin,day_end,weighting = "marginal", variable_of_interest = "t1d", control = trainControl(method = "repeatedcv", number = 5, repeats = 2,classProbs = TRUE,summaryFunction = twoClassSummary,savePredictions = TRUE)){
 
      # organise data base to be used with conventional ml and logistic approach
     
      dataset_ml[[variable_of_interest]] <- factor(dataset_ml[[variable_of_interest]],labels = c("Yes","No"))
      # organise data base to be used with conventional time dependant approach
      
      dataset_timedep[[variable_of_interest]] <- factor(dataset_timedep[[variable_of_interest]],labels = c("Yes","No"))
      
     
      if ( method != "Cox") {
        # formula for the models
        variables_for_prediction <- list_variable_f(day_begin,complexity)
        formula.model <- as.formula(paste0(variable_of_interest,"~",paste(variables_for_prediction, collapse = " + ")))
        
        
        model_T <- train(formula.model, data = dataset_ml, method = method, trControl = control,metric = 'ROC')
        # neeed to check we select cross validation score
        score <- left_join(model_T$bestTune, model_T$pred) %>% select(c("pred","obs","No","Yes","rowIndex"))
        score <- score %>% group_by(rowIndex) %>% summarise(score_mean = mean(No))
        ################### compute AUC score with score achieve with machine learning
        delta <- if_else(dataset_timedep[[variable_of_interest]] == "No",1,0)
        ROC.T <- timeROC(T = dataset_timedep$last_clinic_visit_agedys,
                         delta = delta,marker = score$score_mean,
                         cause = 1, weighting = weighting,
                         times = day_end,
                         iid = TRUE)
        names_tAUC <- paste0("t_AUC_GRS",method,"_complexity_",complexity,"_day_begin_",day_begin,"_day_end_",day_end)
      
        
      }
      
      if ( method == "Cox") {
        
        # formula for the models
        variables_for_prediction <- list_variable_f(day_begin,complexity)
        
        formula.model <- as.formula(paste0("Surv(last_clinic_visit_agedys, t1d)","~",paste(variables_for_prediction, collapse = " + ")))
        
        dataset_ml[[variable_of_interest]] <- as.numeric(dataset_ml[[variable_of_interest]]) - 1
        #computeCox model
        res.cox <- coxph(formula.model, data = dataset_ml)
        
        # extract linear predictio in the log hazard function
        marker_score <- predict(res.cox, dataset_ml, type = "risk")
      
        
        ################### compute AUC score with score achieve with Cox model
        delta <- if_else(dataset_timedep[[variable_of_interest]] == "No",1,0)
        ROC.T <- timeROC(T = dataset_timedep$last_clinic_visit_agedys,
                         delta = delta,marker = marker_score,
                         cause = 1, weighting = weighting,
                         times = day_end,
                         iid = TRUE)
        names_tAUC <- paste0("t_AUC_",method,"_complexity_",complexity,"_day_begin_",day_begin)
        
        
      }
      # save results
     save(ROC.T, file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/",names_tAUC,".RData"))
  return(ROC.T)
}


Cox_landmark <- function(complexity,dataset_ml,day_begin,day_end, variable_of_interest = "t1d",pathSaveModels){
  
  # organise data base to be used with conventional ml and logistic approach
  
  dataset_ml[[variable_of_interest]] <- factor(dataset_ml[[variable_of_interest]],labels = c("Yes","No"))
  # organise data base to be used with conventional time dependant approach
  
  # formula for the models
  variables_for_prediction <- list_variable_f(day_begin,complexity)
  
  formula.model <- as.formula(paste0("Surv(last_clinic_visit_agedys, t1d)","~",paste(variables_for_prediction, collapse = " + ")))
  
  dataset_ml[[variable_of_interest]] <- as.numeric(dataset_ml[[variable_of_interest]]) - 1
  
  
  res.cox <- coxph(formula.model, data = dataset_ml)
  
  names_tAUC <- paste0("Cox_model_","_complexity_",complexity,"_day_begin_",day_begin)
  
  save(list = c("res.cox"), file = paste0(pathSaveModels,names_tAUC,".RData"))
  return("done")
}
