#############################################################
## test for proportional-hazards assumption
## ferratlauric@gmail.com - May 2018
#############################################################
library("survival")
library(survminer)

method <- "Cox"
# method <- "gbm"
complexity <- "abn_grs_fdr"
# complexity <- "abn_grs_fdr_weight"
# complexity <- "full_model_1"
# complexity <- "very_simple"
day_beginv <- c(60,365.25,365.25 + 183,365.25*2 + seq(0,5*365.25,365))

n_time_begin <- length(day_beginv)


for (i in 1:n_time_begin) {
  day_begin <- day_beginv[i]
names_tAUC <- paste0("Cox_model_","_complexity_",complexity,"_day_begin_",day_begin)

load(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/Cox_landmark/",names_tAUC,".RData"))
test.ph <- cox.zph(res.cox)
print(day_begin)
print(test.ph)
g <- ggcoxzph(test.ph)
print(g)
readline("Press <return to continue") 
}
