person1 <- dataset_ml[dataset_ml$grs1>12&dataset_ml$fdr == 1&dataset_ml$number_autoantibody > 1,]
person1 <- person1[1,]
 
person2 <- dataset_ml[dataset_ml$grs1>10&dataset_ml$grs1<11&dataset_ml$fdr == 0&dataset_ml$number_autoantibody == 1,]
person2 <- person2[1,]

person3 <- dataset_ml[dataset_ml$grs1>8&dataset_ml$fdr == 0&dataset_ml$number_autoantibody == 0,]
person3 <- person3[1,]

people <- rbind(person1,person2,person3)
lp.pred <- predict(res.cox,
                   type="lp",
                   newdata=people)
# Baseline Function
base <- basehaz(res.cox)
base[base$time %in% c(731+365,1827,2557),]
# Base value H0 = 0.025880965 at 59 Days
# Predicted Value at time 59 days
base_time <- base[base$time %in% c(731+365,1827,2557),"hazard"]
Pred.val_1 <- base_time[1]*exp(lp.pred)
Pred.val_1
low_val_1 <- base_time[1]*exp(lp.pred) - 1.96 * exp(lp.pred)*
Pred.val_2 <- base_time[2]*exp(lp.pred)
Pred.val_2
Pred.val_3 <- base_time[3]*exp(lp.pred)
Pred.val_3


summary(survfit(res.cox,person3))
