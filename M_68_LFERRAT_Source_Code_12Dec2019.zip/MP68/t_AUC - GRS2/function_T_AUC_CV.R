# pipeline functions

#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################

tAUC_ml_CV <- function(method,complexity,dataset_ml,day_begin,day_end, weighting = "marginal", variable_of_interest = "t1d", k = 3, n_nested = 10,path = codeSaveModels){
  
  # organise data base to be used with conventional ml and logistic approach
  
  dataset_ml[[variable_of_interest]] <- factor(dataset_ml[[variable_of_interest]],labels = c("Yes","No"))
  # organise data base to be used with conventional time dependant approach
  
  # formula for the models
  variables_for_prediction <- list_variable_f(day_begin,complexity)
  
  formula.model <- as.formula(paste0("Surv(last_clinic_visit_agedys, t1d)","~",paste(variables_for_prediction, collapse = " + ")))
  
  dataset_ml[[variable_of_interest]] <- as.numeric(dataset_ml[[variable_of_interest]]) - 1
    #####CV
  for (j in 1:n_nested) {
  #Randomly shuffle the data
  dataset_ml <- dataset_ml[sample(nrow(dataset_ml)),]
  
  #Create 10 equally size folds
  folds <- cut(seq(1,nrow(dataset_ml)),breaks = k,labels = FALSE)
  
  # folds <- createFolds(factor(dataset_ml$t1d), k = k, list = FALSE)
  #Perform 10 fold cross validation
  for (i in 1:k) {
    #Segement your data by fold using the which() function 
    testIndexes <- which(folds == i,arr.ind = TRUE)
    testData <- dataset_ml[testIndexes, ]
    trainData <- dataset_ml[-testIndexes, ]

    #computeCox model
    res.cox <- coxph(formula.model, data = trainData)
    
    # extract linear predictio in the log hazard function
    marker_score <- predict(res.cox, testData, type = "risk")
    
    ################### compute AUC score with score achieve with Cox model
    delta <- testData[[variable_of_interest]]
    ROC.T <- timeROC(T = testData$last_clinic_visit_agedys,
                     delta = delta,marker = marker_score,
                     cause = 1, weighting = weighting,
                     times = day_end,
                     iid = TRUE)
    names_tAUC <- paste0("t_AUC_",method,"_complexity_",complexity,"_day_begin_",day_begin,"_day_end_",paste0(day_end - day_begin,collapse = "_"),"_kfold_",k,"_fold_",i,"_nested_",j)
    ###### count the number of people who develop t1d at futur interval
    nday <- length(day_end)
    nt1d <- rep(0,nday)
      for (l in 1:nday) {
      nt1d[l] <- sum((testData$last_clinic_visit_agedys < day_end[l]) & delta)
      }
    
    n_people_2_keep <- rep(0,nday)
    for (l in 1:nday) {
      people_in_danger <- testData$last_clinic_visit_agedys < day_end[l] & delta
      minimum_score <- quantile(marker_score[people_in_danger],0.05)
      n_people_2_keep_in_study_l <- marker_score > minimum_score
      n_people_2_keep[l] <- sum(n_people_2_keep_in_study_l)
    }
    ntot <- length(delta)
  # save results
  save(list = c("ROC.T","nt1d","ntot","n_people_2_keep"), file = paste0(path,names_tAUC,".RData"))
  }
  }
   return("done")
  
}
