tAUC_ml_v_CV <- function(complexity,dataset_ml,dataset_timedep,day_begin,day_end,weighting = "marginal", variable_of_interest = "t1d",k = 3, savePredictions = TRUE){
  # organise data base to be used with conventional ml and logistic approach
  dataset_ml[[variable_of_interest]] <- factor(dataset_ml[[variable_of_interest]],labels = c("Yes","No"))
  # organise data base to be used with conventional time dependant approach
  dataset_timedep[[variable_of_interest]] <- factor(dataset_timedep[[variable_of_interest]],labels = c("Yes","No"))
  # formula for the models
  variables_for_prediction <- list_variable_f(day_begin,complexity)
  
  formula.model <- as.formula(paste0("Surv(last_clinic_visit_agedys, t1d)","~",paste(variables_for_prediction, collapse = " + ")))
  
  dataset_ml[[variable_of_interest]] <- as.numeric(dataset_ml[[variable_of_interest]]) - 1
  #Randomly shuffle the data
  dataset_ml <- dataset_ml[sample(nrow(dataset_ml)),]
  
  #Create 10 equally size folds
  folds <- cut(seq(1,nrow(dataset_ml)),breaks = k,labels = FALSE)
  listdata_peryear_perfold <- list()
  listdata_perfold <- list()
  listdata_peryear <- list()
  #Perform 10 fold cross validation
  for (i in 1:k) {
    #Segement your data by fold using the which() function 
    testIndexes <- which(folds == i,arr.ind = TRUE)
    testData <- dataset_ml[testIndexes, ]
    trainData <- dataset_ml[-testIndexes, ]
    
    #computeCox model
    res.cox <- coxph(formula.model, data = trainData)
    
    # extract linear predictio in the log hazard function
    marker_score <- predict(res.cox, testData, type = "risk")
    
    ################### compute AUC score with score achieve with Cox model
    delta <- testData[[variable_of_interest]]
    ROC.T <- timeROC(T = testData$last_clinic_visit_agedys,
                     delta = delta,marker = marker_score,
                     cause = 1, weighting = weighting,
                     times = day_end,
                     iid = TRUE)
    
    TP <- ROC.T$TP
    FP <- ROC.T$FP
    # compute interpolation to be able to compare the ROC curve
    for (j in 1:length(day_end)) {
      dat <- data.frame(TP[,j],FP[,j]) 
      colnames(dat) <- c("TP","FP")
      listdata_peryear_perfold[[j]] <- data.frame(with(dat,
                                                       approx(FP,TP,xout = seq(0,1,0.01),method = "linear")
      ),
      method = "spline()"
      )
    }
    listdata_perfold[[i]] <- listdata_peryear_perfold
  }
  
  for (j in 1:length(day_end)) {
    dataij <- list()
  for (i in 1:k) {
    dataij[[i]] <- listdata_perfold[[i]][[j]]
  }
    dataij2 <- dplyr::bind_rows(dataij,.id = "groups")
    dataij3 <- dataij2 %>% mutate(x = round(x*1000,digits = 3)/1000) %>% 
      group_by(x) %>%
      summarise(FP = mean(x), TP = mean(y))
    listdata_peryear[[j]] <- dataij3
    print(dataij3)
  
  }
  return(listdata_peryear)
}
