##### Figure 1
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################
# library to load

source('C:/Users/Lauric/Dropbox/PostdocTeddy/main.R')
source('C:/Users/Lauric/Dropbox/PostdocTeddy/t_AUC - GRS2/plot_t_AUC_CI.R')
source('C:/Users/Lauric/Dropbox/PostdocTeddy/t_AUC - GRS2/article_figures/RoC_save_different_models_CV.R')

fig1 <- ggdraw() +
  draw_plot(p1, x = 0, y = 0, width = 0.5, height = 1) +
  draw_plot(p, x = 0.5, y = 0, width = 0.5, height = 1) +
  draw_plot_label(label = c("A", "B"), size = 15,
                  x = c(0, 0.5), y = c(1,1))
fig1
ggsave("C:/Users/Lauric/Dropbox/TEDDY prediction model paper/figures and tables/figure1.jpg",width = 6.8*1.7, height = 6.8*1.7/2)

library("tidyverse")
library("officer")
library("rvg")
read_pptx() %>%
  add_slide(layout = "Title and Content", master = "Office Theme") %>%
  ph_with_vg(code = print(fig1), type = "body") %>%
  print(target = "C:/Users/Lauric/Dropbox/TEDDY prediction model paper/figures and tables/figure1.pptx")

