##### templatenalyse results t_AUC already saved
#############################################################
## ## ferratlauric@gmail.com - Decembre 2018
#############################################################
# library to load

library(timeROC)
library(survival)
library(caret)
library(cowplot)

source('C:/Users/Lauric/Desktop/Postdoc/PCA/SEARCH/ggplotAUC.R')

# 1 
method_1 <- "Cox"
# method_1 <- "gbm"
# complexity_1 <- "simple"
# complexity_1 <- "very_simple"
complexity_1 <- "grs1"
#2
method_2 <- "Cox"
# method_2 <- "gbm"
# complexity_2 <- "simple"
complexity_2 <- "grs_fdr"
# complexity_2 <- "abn_grs_fdr"
method_3 <- "Cox"
complexity_3 <- "abn_grs_fdr"

load(file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC/figures/t_AUC_",method_1,"_",complexity_1,"_CV",".Rdata"))
AUC_m_1 <- AUC_m
seAUC_m_1 <- seAUC_m

load(file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC/figures/t_AUC_",method_2,"_",complexity_2,"_CV",".Rdata"))
AUC_m_2 <- AUC_m
seAUC_m_2 <- seAUC_m

load(file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC/figures/t_AUC_",method_3,"_",complexity_3,"_CV",".Rdata"))
AUC_m_3 <- AUC_m
seAUC_m_3 <- seAUC_m

prediction_at <- row.names(AUC_m)
confup_1 <- create_IC_se(AUC_m_1,seAUC_m_1,confidencev = 1.96, class = "up")
conflow_1 <- create_IC_se(AUC_m_1,seAUC_m_1,confidencev = 1.96, class = "low")
confup_2 <- create_IC_se(AUC_m_2,seAUC_m_2,confidencev = 1.96, class = "up")
conflow_2 <- create_IC_se(AUC_m_2,seAUC_m_2,confidencev = 1.96, class = "low")
confup_3 <- create_IC_se(AUC_m_3,seAUC_m_3,confidencev = 1.96, class = "up")
conflow_3 <- create_IC_se(AUC_m_3,seAUC_m_3,confidencev = 1.96, class = "low")

AUC_m_1[1,1] <- NaN
p1 <- ggplotAUC2(AUC_m_1,conflow_1, confup_1,prediction_at ,names_var = "horizon time",colour_up = "red")
p1
ggsave(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC/figures/people_in_survey_CV_all",method_1,"_",complexity_1,".jpg"),width = 9.6,height = 8.52)

AUC_m_dif <- (AUC_m_2 - AUC_m_1) 
p2 <- ggplot_heatmap(AUC_m_dif,prediction_at ,names_var = "horizon time",name_ylab = "")
p2
ggsave(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC/figures/heatmap_CV",method_2,"_",complexity_2,"_",method_1,"_",complexity_1,".jpg"),width = 9.49,height =  8.52)


AUC_m_dif <- (AUC_m_3 - AUC_m_2) 
p3 <- ggplot_heatmap(AUC_m_dif,prediction_at ,names_var = "horizon time",name_ylab = "")
p3
ggsave(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC/figures/heatmap_CV",method_3,"_",complexity_3,"_",method_2,"_",complexity_2,".jpg"),width = 9.49,height =  8.52)


ggdraw() +
  draw_plot(p1, x = 0, y = 0, width = 0.45, height = 1) +
  draw_plot(p2, x = .42, y = 0, width = 0.3, height = 1) +
  draw_plot(p3, x = .7, y = 0, width = 0.3, height = 1) +
  draw_plot_label(label = c("A", "B", "C"), size = 15,
                  x = c(0, 0.5, 0.75), y = c(1, 1, 1))

ggsave(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC/figures/heatmap_CV_all",".jpg"),width = 16,height =  6.13)

AUC_m_2[1,1] <- NaN
AUC_m_3[1,1] <- NaN
p4 <- ggplotAUC2(AUC_m_2,conflow_2, confup_2,prediction_at ,names_var = "horizon time",colour_up = "red",name_ylab = "")
p5 <- ggplotAUC2(AUC_m_3,conflow_3, confup_3,prediction_at ,names_var = "horizon time",colour_up = "red",name_ylab = "")

ggdraw() +
  draw_plot(p1, x = 0, y = 0, width = 0.33, height = 1) +
  draw_plot(p4, x = .34, y = 0, width = 0.33, height = 1) +
  draw_plot(p5, x = .67, y = 0, width = 0.33, height = 1) +
  draw_plot_label(label = c("A", "B", "C"), size = 15,
                  x = c(0, 0.34, 0.67), y = c(1, 1, 1))

ggsave(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC/figures/heatmap_CV_all_2",".jpg"),width = 19,height =  6.13)
