##### templatenalyse results t_AUC already saved
#############################################################
## ## ferratlauric@gmail.com - Decembre 2018
#############################################################
# library to load

library(timeROC)
library(survival)
library(caret)
source('C:/Users/Lauric/Desktop/Postdoc/PCA/SEARCH/ggplotAUC.R')

# 1 
method_1 <- "Cox"
# method_1 <- "gbm"
# complexity_1 <- "simple"
# complexity_1 <- "very_simple"
complexity_1 <-  "abn_grs_fdr"
#2
method_2 <- "Cox"
# method_2 <- "gbm"
# complexity_2 <- "simple"
complexity_2 <- "full_model_pvalue"
# complexity_2 <- "abn_grs_fdr"


load(file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/figures/t_AUC_",method_1,"_",complexity_1,"_CV",".Rdata"))
AUC_m_1 <- AUC_m
seAUC_m_1 <- seAUC_m

load(file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/figures/t_AUC_",method_2,"_",complexity_2,"_CV",".Rdata"))
AUC_m_2 <- AUC_m
seAUC_m_2 <- seAUC_m

prediction_at <- row.names(AUC_m)

AUC_m_dif <- (AUC_m_1 - AUC_m_2) 
ggplot_heatmap(AUC_m_dif,prediction_at ,names_var = paste0("t-AUC dif between",complexity_1,"_",method_1," and ",complexity_2,"_",method_2))
ggsave(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC/figures/heatmap_CV",method_1,"_",complexity_1,"_",method_2,"_",complexity_2,".jpg"),width = 9.49,height =  8.52)
