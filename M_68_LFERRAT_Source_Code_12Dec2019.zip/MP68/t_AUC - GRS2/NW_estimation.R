##### templatenalyse results t_AUC
#############################################################
## ## ferratlauric@gmail.com - December 2018
#############################################################
##### main t-AUC
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################
# library to load
library(timeROC)
library(survival)
library(caret)
set.seed(123)
source(paste0(codePath,"/t_AUC - GRS2/function_T_AUC.R"))
source(paste0(codePath,"/t_AUC - GRS2/list_variable_f.R"))

tAUC_ml_train_test <- function(method,complexity,dataset_ml_train,dataset_ml_test,dataset_timedep,day_begin,day_end,weighting = "marginal", variable_of_interest = "t1d", control = trainControl(method = "repeatedcv", number = 5, repeats = 2,classProbs = TRUE,summaryFunction = twoClassSummary,savePredictions = TRUE)){
  
  # organise data base to be used with conventional ml and logistic approach
  
  dataset_ml_train[[variable_of_interest]] <- factor(dataset_ml_train[[variable_of_interest]],labels = c("Yes","No"))
  # organise data base to be used with conventional time dependant approach
  
  dataset_timedep[[variable_of_interest]] <- factor(dataset_timedep[[variable_of_interest]],labels = c("Yes","No"))
  
  
  # formula for the models
  variables_for_prediction <- list_variable_f(day_begin,complexity)
  
  formula.model <- as.formula(paste0("Surv(last_clinic_visit_agedys, t1d)","~",paste(variables_for_prediction, collapse = " + ")))
  
  dataset_ml_train[[variable_of_interest]] <- as.numeric(dataset_ml_train[[variable_of_interest]]) - 1
  #computeCox model
  res.cox <- coxph(formula.model, data = dataset_ml_train)
  
  # extract linear predictio in the log hazard function
  marker_score <- predict(res.cox, dataset_ml_test, type = "risk")
  
  
  ################### compute AUC score with score achieve with Cox model
  delta <- if_else(dataset_timedep[[variable_of_interest]] == "No",1,0)
  ROC.T <- timeROC(T = dataset_timedep$last_clinic_visit_agedys,
                   delta = delta,marker = marker_score,
                   cause = 1, weighting = weighting,
                   times = day_end,
                   iid = TRUE)
  names_tAUC <- paste0("t_AUC_",method,"_complexity_",complexity,"_day_begin_",day_begin)
  
  # save results
  # save(ROC.T, file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/NW_estimation_",names_tAUC,".RData"))
  print(ROC.T)
  return(ROC.T)
  
}

AUC_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
seAUC_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
method <- "Cox"
# method <- "gbm"
complexity <- "abn_grs_fdr"
# complexity <- "abn_grs_fdr_weight"
day_beginv <- c(60,365.25,365.25 + 183,365.25*2 + seq(0,5*365.25,365))
day_endv <- c(365.25,365.25*3,5*365.25,8*365.25)

n_time_begin <- length(day_beginv)
n_time_end <- length(day_endv)
for (i in 1:n_time_begin) {
  for (j in 1:n_time_end) {
    day = day_beginv[i]
    dayend = day_endv[j] + day
    source(paste0(codePath,"Extract_information_per_date.R"))
    dataset_ml_train <- finaldata
    dataset_ml_test <- finaldata[finaldata$race_ethnicity %in% c(1,3,4),]
    day = day_beginv[i]
    dayend = Inf
    source(paste0(codePath,"Extract_information_per_date.R"))
    dataset_timedep <- finaldata[finaldata$race_ethnicity %in% c(1,3,4),]
    print(day)
    print(day_endv[j] + day)
    ROC.T <- tAUC_ml_train_test(method,complexity,dataset_ml_train,dataset_ml_test,dataset_timedep,day_beginv[i],day_beginv[i] + day_endv[j])
    AUC_m[i,j] <- ROC.T$AUC[2]
    seAUC_m[i,j] <- ROC.T$inference$vect_sd_1[2]
    }
}
apply(AUC_m,2,mean,na.rm = TRUE)
method <- "Cox"

day_endv <- c(365.25,365.25*3,5*365.25,8*365.25)


n_time_begin <- length(day_beginv)
n_time_end <- length(day_endv)

AUC_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
seAUC_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
nt1d_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
ntot_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
n_2_keep_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)

for (j in 1:n_time_begin) {
      # names_tAUC <- paste0("t_AUC_",method,"_complexity_",complexity,"_day_begin_",day_beginv[j],"_day_end_",paste0(day_endv,collapse = "_"),"_kfold_",k,"_fold_",i)
      names_tAUC <- paste0("NW_estimation_t_AUC",method,"_complexity_",complexity1,"_day_begin_",day_beginv[j],"_day_end_",paste0(day_endv,collapse = "_"))
      # load results
      load(file = paste0(pathSaveModels,names_tAUC,".RData"))
      AUC_m_k[i,] <- ROC.T$AUC
      seAUC_m_k[i,] <- ROC.T$inference$vect_sd_1
      nt1d_m_k[i,] <- nt1d
      ntot_m_k[i,] <- ntot
      n_2_keep_m_k[i,] <- n_people_2_keep
}

if (complexity1 == "abn") {  
  prediction_at <-  c("1 year","18 months","2 years","3 years","4 years","5 years","6 years","7 years")
}else {
  prediction_at <-  c("3 months","1 year","18 months","2 years","3 years","4 years","5 years","6 years","7 years")
}

prediction_for <- c("1 year","3 years","5 years","8 years")

row.names(AUC_m) <- prediction_at 
colnames(AUC_m) <- prediction_for

confup <- create_IC_se(AUC_m,seAUC_m,confidencev = 1.96, class = "up")
conflow <- create_IC_se(AUC_m,seAUC_m,confidencev = 1.96, class = "low")


p1 <- ggplotAUC2(AUC_m,conflow, confup,prediction_at ,names_var = "horizon time")



#############################


AUC_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
seAUC_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
nt1d_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
ntot_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
n_2_keep_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
k <- 3

AUC_m_k <- matrix(, nrow = k, ncol = n_time_end)
seAUC_m_k <- matrix(, nrow = k, ncol = n_time_end)
nt1d_m_k <- matrix(, nrow = k, ncol = n_time_end)
ntot_m_k <- matrix(, nrow = k, ncol = n_time_end)
n_2_keep_m_k <- matrix(, nrow = k, ncol = n_time_end)

n_nested <- 10
AUC_m_n_nested <- matrix(, nrow = n_nested, ncol = n_time_end)
seAUC_m_n_nested <- matrix(, nrow = n_nested, ncol = n_time_end)
nt1d_m_n_nested <- matrix(, nrow = n_nested, ncol = n_time_end)
ntot_m_n_nested <- matrix(, nrow = n_nested, ncol = n_time_end)
n_2_keep_m_n_nested <- matrix(, nrow = n_nested, ncol = n_time_end)
for (j in 1:n_time_begin) {
  for (l in 1:n_nested) {
    for (i in 1:k) {
      
      # names_tAUC <- paste0("t_AUC_",method,"_complexity_",complexity,"_day_begin_",day_beginv[j],"_day_end_",paste0(day_endv,collapse = "_"),"_kfold_",k,"_fold_",i)
      names_tAUC <- paste0("t_AUC_",method,"_complexity_",complexity2,"_day_begin_",day_beginv[j],"_day_end_",paste0(day_endv,collapse = "_"),"_kfold_",k,"_fold_",i,"_nested_",l)
      # load results
      load(file = paste0(pathSaveModels,names_tAUC,".RData"))
      AUC_m_k[i,] <- ROC.T$AUC
      seAUC_m_k[i,] <- ROC.T$inference$vect_sd_1
      nt1d_m_k[i,] <- nt1d
      ntot_m_k[i,] <- ntot
      n_2_keep_m_k[i,] <- n_people_2_keep
    }
    AUC_m_n_nested[l,] <- colMeans(AUC_m_k, na.rm = TRUE, dims = 1)
    seAUC_m_n_nested[l,] <- apply(AUC_m_k,2,var)
    nt1d_m_n_nested[l,] <- colSums(nt1d_m_k,na.rm = TRUE, dims = 1)
    ntot_m_n_nested[l,] <- colSums(ntot_m_k,na.rm = TRUE, dims = 1)
    n_2_keep_m_n_nested[l,] <- colMeans(n_2_keep_m_k,na.rm = TRUE, dims = 1)
  }
  AUC_m[j,] <- colMeans(AUC_m_n_nested, na.rm = TRUE, dims = 1)
  seAUC_m[j,] <- apply(seAUC_m_n_nested,2,function(x) sqrt(mean(x,na.rm = TRUE)))
  nt1d_m[j,] <- colMeans(nt1d_m_n_nested,na.rm = TRUE, dims = 1)
  ntot_m[j,] <- colMeans(ntot_m_n_nested,na.rm = TRUE, dims = 1)
  n_2_keep_m[j,] <- colMeans(n_2_keep_m_n_nested,na.rm = TRUE, dims = 1)
}

prediction_for <- c("1 year","3 years","5 years","8 years")

row.names(AUC_m) <- prediction_at 
colnames(AUC_m) <- prediction_for

confup <- create_IC_se(AUC_m,seAUC_m,confidencev = 1.96, class = "up")
conflow <- create_IC_se(AUC_m,seAUC_m,confidencev = 1.96, class = "low")


p2 <- ggplotAUC2(AUC_m,conflow, confup,prediction_at ,names_var = "horizon time")

fig1 <- ggdraw() +
  draw_plot(p1, x = 0, y = 0, width = 0.5, height = 1) +
  draw_plot(p2, x = 0.5, y = 0, width = 0.5, height = 1) +
  draw_plot_label(label = c("a", "b"), size = 15,
                  x = c(0, 0.5), y = c(1,1))
fig1

ggsave(paste0(pathfigures_tables,table_name,".jpg"),width = 6.8*1.5,height = 6.8)

# ggplotAUC3(AUC_m,conflow, confup,ntot_m,nt1d_m,prediction_at ,names_var = "horizon time")
# ggsave(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/figures/t_AUC_CV_all",method,"_",complexity,".jpg"),width = 9.6,height = 8.52)

# save(list = c("AUC_m","confup","conflow","seAUC_m"),file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/figures/t_AUC_",method,"_",complexity,"_CV",".Rdata"))


# row.names(n_2_keep_m) <- prediction_at 
# colnames(n_2_keep_m) <- prediction_for
# row.names(ntot_m) <- prediction_at 
# colnames(ntot_m) <- prediction_for
# ratio_m <- n_2_keep_m/ntot_m
# 
# ggplotAUC2(ratio_m,n_2_keep_m, ntot_m,prediction_at ,names_var = "horizon time")
# ggsave(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/figures/people_in_survey_CV_all",method,"_",complexity,".jpg"),width = 9.6,height = 8.52)

