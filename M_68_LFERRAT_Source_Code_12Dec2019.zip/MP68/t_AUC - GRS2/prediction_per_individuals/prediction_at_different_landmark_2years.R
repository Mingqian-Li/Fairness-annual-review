library("dplyr")
library("ggplot2")
library("plotly")
library("survey")
library(survival)


result_time_serie_proba <- list()
complexity <- "abn_grs_fdr"
peopleID <- c("684620","238047","785700","332565")

###
# 684620 fdr + high GRS
# 238047 fdr + high GRS + 2 autoantibody
#785700  no fdr + low GRS + 0 autoantibody
#332565 no fdr + low GRS + 2 autoantibody

# "593242","415649" - > nothing
# "809453" -> 1 autoantibody at 450 then nothing
# "825463" -> 1 autoantibody then 3 then T1D
# "744850" -> 3 autoantibody after 2 years then T1D.
# "824143" -> quick progression
nyv <- c(1,3,5)
day <- 365.25 * 2
dayend = Inf
source(paste0(codePath,"Extract_information_per_date.R"))

names_tAUC <- paste0("Cox_model_","_complexity_",complexity,"_day_begin_",day)
load(file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/Cox_landmark/",names_tAUC,".RData"))

dataset_ml <- finaldata
for (people in peopleID) {
  k <- 1
  personID <- people
  # collect the coefficient for each landmark point
  prediction_df <- matrix(0,length(nyv) , 7)
  for (i in nyv) {
    ny <- i
    print(i)
    
    if (dim(dataset_ml[dataset_ml$MP68_MaskID == personID,])[1] != 0) {
      # dataset_ml[dataset_ml$MP68_MaskID == personID,"GRS2"] <- 12.3 
      # dataset_ml[dataset_ml$MP68_MaskID == personID,"number_autoantibody"] <- 1
      prediction_i <- summary(survfit(res.cox,dataset_ml[dataset_ml$MP68_MaskID == personID,]),times = day + ny*365.25)
      prediction_df[k,] <- c(prediction_i$time,prediction_i$n.risk,prediction_i$n.event,prediction_i$surv,prediction_i$std.err,prediction_i$lower,prediction_i$upper)
      k <- k + 1
    }
  }
  prediction_df <- data.frame(prediction_df)
  colnames(prediction_df) <- c("time", "n.risk", "n.event","survival","std.err","lower","upper")
  #prediction_df$ID <- personID
  # confidence interval formula log transformation  eq 4.3.2 from Klein, John P.  Moeschberger, Melvin L. 2003
  # A Note on Confidence Intervals and Bands for the Survival Function Based on Transformations Borgan, Ørnulf Liestøl, Knut
  result_time_serie_proba[[personID]] <- prediction_df
}


proba_times_series <- bind_rows(result_time_serie_proba,.id = "personID")
proba_times_series2 <- proba_times_series %>%
  filter( time != 0) %>% 
  mutate( time = round((time - 2 * 365.25)/365.25*2)/2) %>% 
  mutate(proba = (1 - survival)*100) %>% 
  mutate(lower1 = (1 - upper)*100) %>% 
  mutate(upper = (1 - lower)*100) %>% 
  mutate(lower = lower1)

T1D_onset <- finaldata[finaldata$MP68_MaskID %in% peopleID,c("MP68_MaskID","t1d","t1d_diag_agedys")]
T1D_onset$MP68_MaskID <- as.character(T1D_onset$MP68_MaskID)
T1D_onset$t1d_diag_agedys <- T1D_onset$t1d_diag_agedys/365.25
T1D_onset_y <- proba_times_series2 %>% 
  group_by(personID) %>% 
  top_n(1,time) %>% 
  ungroup() %>% 
  mutate(proba = 1 - survival) %>% 
  select(proba,personID)
T1D_onset_d <- left_join(T1D_onset_y,T1D_onset, by = c("personID" = "MP68_MaskID")) %>% 
  filter(t1d == 1) %>% 
  mutate(time = t1d_diag_agedys) %>% 
  select(personID,time,t1d,proba)

proba_times_series3 <- proba_times_series2 %>% 
  mutate(t1d = 0,
         proba = 1 - survival) %>% 
  select(personID,time,t1d,proba)
data_proba  <- rbind(proba_times_series3, T1D_onset_d)                       
p <- ggplot(data_proba, aes(x = time, y = proba,colour = personID)) +
  geom_point(data = T1D_onset_d,size = 6,aes(shape = t1d),stroke = 2) +
  geom_line(size = 0.5) + 
  xlab("Age at Prediction Scoring (years)") + 
  ylab("probability") +
  # coord_cartesian(ylim = c(0,1)) +
  geom_ribbon(data = proba_times_series2, aes(ymin = lower,ymax = upper,fill = personID),
              alpha = 0.3,show.legend = FALSE, colour = "transparent") +
  # ggtitle("Fig 1. Time-dependent AUC in the Teddy database for\n several values of landmark age and horizon times") + 
  theme_bw() +
  scale_colour_discrete(name = "Individual") +
  scale_shape_manual(name = "Event",
                     values = c(16,4),
                     labels = c("T1D onset"))
p

proba_times_series2

##################### non autoantibody
library(flextable)
library(officer)
myft <- regulartable(
  proba_times_series2, 
  col_keys = c("personID","time","proba", "lower", "upper"))
myft
myft <- theme_vanilla(myft)
myft
myft <- merge_v(myft, j = c("personID"))
myft

myft <- autofit(myft)
myft <- align( myft, align = "center", part = "all" )
myft
doc <- read_docx()
doc <- body_add_flextable(doc, value = myft)
# print(doc, target = "individualprediction.docx")
