##### main t-AUC
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################
# library to load
library(timeROC)
library(survival)
library(caret)
library(My.stepwise)
library(survival)
library(pec)
set.seed(123)


day_beginv <- c(183,365.25,365.25 + 183,365.25*2 + seq(0,6*365.25,365))



n_time_begin <- length(day_beginv)

sink("sink-examp.txt")


for (i in 1:(n_time_begin - 1)) {
  day = day_beginv[i]
  dayend = Inf
  source(paste0(codePath,"Extract_information_per_date.R"))
  dataset_ml <- finaldata
  dataset_ml <- dataset_ml %>% mutate(time = if_else(t1d == 1,t1d_diag_agedys,last_clinic_visit_agedys),
                                      t1d = as.numeric(as.character(t1d)),
                                      fdr = as.numeric(fdr) - 1)
  my.variable.list <- c("GRS2","fathers_age","maternal_age","resp_gest_inf","fevergrp_tot_day","common_cold_tot_day","laryngitis_trac_tot_day","influenza_tot_day","acute_sinusitis","resp_tot_day","gastro_tot_day","fdr","weight","number_autoantibody")
  # f <- selectCox(Surv(time,t1d)~   GRS2 + resp_gest_inf + fevergrp_tot_day + common_cold_tot_day + laryngitis_trac_tot_day + influenza_tot_day + acute_sinusitis + resp_tot_day + gastro_tot_day + fdr + weight + number_autoantibody,data = dataset_ml,rule = "aic")
  # res <- My.stepwise.coxph(Time= "time",Status = "t1d",variable.list = my.variable.list,data= dataset_ml)
  print(day)
  # print(f$In)
model <- coxph(Surv(time,t1d)~   1 ,data = dataset_ml)
  step(   model,scope = as.formula(~GRS2 + resp_gest_inf + fevergrp_tot_day + common_cold_tot_day + laryngitis_trac_tot_day + influenza_tot_day + acute_sinusitis + resp_tot_day + gastro_tot_day + fdr + weight + number_autoantibody + sex  + country_cd + probio), direction = "both", k = log(dim(dataset_ml)[1]),steps = 5000)
  print(paste0("landmark : ",round(day*10/365)/10," years"))
  #readline(prompt = "Press [enter] to continue")
  }
sink()
# extractAIC(coxph(Surv(time,t1d)~     GRS2  + fdr + weight + number_autoantibody,data = dataset_ml))

