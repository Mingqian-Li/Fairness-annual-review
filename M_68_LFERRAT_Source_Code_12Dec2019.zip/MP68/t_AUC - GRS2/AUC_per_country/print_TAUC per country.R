##### templatenalyse results t_AUC
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################
# library to load
library(timeROC)
library(survival)
library(caret)
library(flextable)
library(officer)
source('C:/Users/Lauric/Desktop/Postdoc/PCA/SEARCH/ggplotAUC.R')

method <- "Cox"
# method <- "gbm"
complexity <- "abn_grs_fdr"
# complexity <- "abn_grs_fdr_weight"
# complexity <- "full_model_1"
# complexity <- "very_simple"
day_beginv <- c(60,365.25,365.25 + 183,365.25*2 + seq(0,5*365.25,365))
day_endv <- c(365.25,365.25*3,5*365.25,8*365.25)

n_time_begin <- length(day_beginv)
n_time_end <- length(day_endv)
AUC_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)
seAUC_m <- matrix(, nrow = n_time_begin, ncol = n_time_end)

for(country in 1:4){
for (i in 1:n_time_begin) {
  for (j in 1:n_time_end) {
    day_begin = day_beginv[i]
    day_end =  day_beginv[i] + day_endv[j]
    # load results
    names_file <- paste0("timeROC",method,"_complexity_",complexity,"_day_begin_",day_begin,"_country_",country)
    load(file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/",names_file,".RData"))
    # extract relevant information
    
    AUC_m[i,j] <- ROC.T$AUC[paste0("t=",day_end)]
    seAUC_m[i,j] <- ROC.T$inference$vect_sd_1[paste0("t=",day_end)]
  
    
  }}

prediction_at <-  c("8 weeks","1 year","18 months","2 years","3 years","4 years","5 years","6 years","7 years")
prediction_for <- c("1 year","3 years","5 years","8 years")

row.names(AUC_m) <- prediction_at 
colnames(AUC_m) <- prediction_for


confup <- create_IC_se(AUC_m,seAUC_m,confidencev = 1.96, class = "up")
conflow <- create_IC_se(AUC_m,seAUC_m,confidencev = 1.96, class = "low")



ggplotAUC2(AUC_m,conflow, confup,prediction_at ,names_var = "future")

ggsave(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/figures/t_AUC_",method,"_",complexity,"_country_",country,".jpg"),width = 9.6,height = 8.52)
}
