##### main t-AUC
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################
# library to load
library(timeROC)
library(survival)
library(caret)
set.seed(123)
source(paste0(codePath,"/t_AUC - GRS2/function_T_AUC.R"))
source(paste0(codePath,"/t_AUC - GRS2/list_variable_f.R"))

TAUC_landmark_per_country <- function(complexity,dataset_ml,day_begin,day_end, variable_of_interest = "t1d",country = 1){
  
  # organise data base to be used with conventional ml and logistic approach
  
  dataset_ml[[variable_of_interest]] <- factor(dataset_ml[[variable_of_interest]],labels = c("Yes","No"))
  # organise data base to be used with conventional time dependant approach
  
  # formula for the models
  variables_for_prediction <- list_variable_f(day_begin,complexity)
  
  formula.model <- as.formula(paste0("Surv(last_clinic_visit_agedys, t1d)","~",paste(variables_for_prediction, collapse = " + ")))
  
  dataset_ml[[variable_of_interest]] <- as.numeric(dataset_ml[[variable_of_interest]]) - 1
  dataset_training <- dataset_ml[dataset_ml$country_cd != country,]
  dataset_country <- dataset_ml[dataset_ml$country_cd == country,]
  
  res.cox <- coxph(formula.model, data = dataset_training)
  
  # extract linear predictio in the log hazard function
  marker_score <- predict(res.cox, dataset_country, type = "risk")
  
  
  ################### compute AUC score with score achieve with Cox model
  delta <- dataset_country[[variable_of_interest]]
  ROC.T <- timeROC(T = dataset_country$last_clinic_visit_agedys,
                   delta = delta,marker = marker_score,
                   cause = 1,
                   times = day_end,
                   iid = TRUE)
  names_file <- paste0("timeROC",method,"_complexity_",complexity,"_day_begin_",day_begin,"_country_",country)
  
  # save results
  save(ROC.T, file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/",names_file,".RData"))
  return(ROC.T)
}

method <- "Cox"
complexity <- "abn_grs_fdr"
print(complexity)
# complexity <- "abn_grs_fdr"
day_beginv <- c(60,365.25,365.25 + 183,365.25*2 + seq(0,8*365.25,365))
# day_beginv <- c(365.25*5 + seq(0,3*365.25,365))
day_endv <- c(365.25,365.25*3,5*365.25,8*365.25,10*365.25)
country <- 1

n_time_begin <- length(day_beginv)
n_time_end <- length(day_endv)

for (country in 1:4) {
for (i in 1:n_time_begin) {
  day = day_beginv[i]
  dayend = Inf
  source(paste0(codePath,"Extract_information_per_date.R"))
  dataset_ml <- finaldata
  TAUC_landmark_per_country(complexity,dataset_ml,day_beginv[i],day_beginv[i] + day_endv, variable_of_interest = "t1d",country = country)
}
}

