##### main t-AUC
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################
# library to load
library(timeROC)
library(survival)
library(caret)
set.seed(123)
source(paste0(codePath,"/t_AUC - GRS2/function_T_AUC.R"))
source(paste0(codePath,"/t_AUC - GRS2/list_variable_f.R"))


method <- "Cox"
print(complexity)

day_beginv <- c(60,365.25,365.25 + 183,365.25*2 + seq(0,8*365.25,365)) + 45
day_endv <- c(365.25,365.25*3,5*365.25,8*365.25,10*365.25)


n_time_begin <- length(day_beginv)
n_time_end <- length(day_endv)

for (i in 1:n_time_begin) {
  day = day_beginv[i]
  dayend = Inf
  source(paste0(codePath,"Extract_information_per_date.R"))
  dataset_ml <- finaldata
  Cox_landmark(complexity,dataset_ml,day_beginv[i],day_beginv[i] + day_endv, variable_of_interest = "t1d",pathSaveModels)
}

