##### templatenalyse results t_AUC
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################
# library to load
library(timeROC)
library(survival)
library(caret)
library(flextable)
library(officer)
source('C:/Users/Lauric/Desktop/Postdoc/PCA/SEARCH/ggplotAUC.R')

method <- "Cox"
# method <- "gbm"
complexity <- "abn_grs_fdr"
# complexity <- "abn_grs_fdr_weight"
# complexity <- "full_model_1"
# complexity <- "very_simple"
day_beginv <- c(60,365.25,365.25 + 183,365.25*2 + seq(0,5*365.25,365))
day_endv <- c(365.25,365.25*3,5*365.25,8*365.25)

n_time_begin <- length(day_beginv)
n_time_end <- length(day_endv)

for (i in 1:n_time_begin) {
  for (j in 1:n_time_end) {
    day_begin = day_beginv[i]
    day_end =  day_beginv[i] + day_endv[j]
    # load results
    names_file <- paste0("Sensitivity_specificity",method,"_complexity_",complexity,"_day_begin_",day_begin)
    load(file = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/",names_file,".RData"))
    # extract relevant information
    
    SE <- ROC.T$TP[,paste0("t=",day_end)]
    SP <- 1 - ROC.T$FP[,paste0("t=",day_end)]
    
    
    table_summary <- data.frame(round(SE,2),round(SP,2))
    colnames(table_summary) <- c("Sensitivity","Specificity")
    table_summary <- table_summary %>% 
                      mutate(Sensitivity = factor(Sensitivity)) %>% 
                      dplyr::group_by(Sensitivity) %>% 
                      mutate(rank=row_number()) %>% 
                      dplyr::filter(rank==1) %>% 
                      select(Sensitivity,Specificity)
        ################## autoantibody ################
    myft <- regulartable(
      table_summary)
    # myft
    myft <- theme_vanilla(myft)
    # myft <- width(myft, width = 1.5)
    myft <- autofit(myft, add_w = 0, add_h = 0)
    myft <- align( myft, align = "center", part = "all" )
    # myft
    
    
    doc <- read_docx()
    doc <- body_add_par(doc,paste0("landmark: ", round(day_begin*2/365.25)/2,", horizon time: ",round(day_endv[j]*2/365.25)/2), style = "Normal")
    doc <- body_add_flextable(doc, value = myft)
    
    print(doc, target = paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC_GRS2/SE_SP/","start year",round(day_begin*2/365.25)/2,"year end",round(day_endv[j]*2/365.25)/2,".docx"))
    
    
  }}

