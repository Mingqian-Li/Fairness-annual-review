##### templatenalyse results t_AUC already saved
#############################################################
## ## ferratlauric@gmail.com - Novembre 2018
#############################################################
# library to load


method <- "Cox"
complexity <- "abn_grs_fdr"

load(file = paste0(pathSaveModels,"t_AUC_",method,"_",complexity,"_CV.Rdata"))


###################################
### withtout 10 and 12 ####

prediction_at <-  c(0.5,1,1.5,2,seq(3,7))
prediction_for <- c(1,3,5,8)
rownames(AUC_m) <- prediction_at 
colnames(AUC_m) <- prediction_for
rownames(conflow) <- prediction_at 
colnames(conflow) <- prediction_for
rownames(confup) <- prediction_at 
colnames(confup) <- prediction_for



data_plot <- AUC_m %>% data.frame() 
data_plot <- data_plot %>% mutate(time_from = row.names(data_plot))
data_plot <- data_plot %>% gather(key = "years",value = "t_AUC",X1,X3,X5,X8)
data_plot_low <- conflow %>% data.frame()
data_plot_low <- data_plot_low %>% mutate(time_from = row.names(data_plot_low))
data_plot_low <- data_plot_low %>% gather(key = "years",value = "t_AUC",X1,X3,X5,X8)
data_plot_up <- confup %>% data.frame()
data_plot_up <- data_plot_up %>% mutate(time_from = row.names(data_plot_up))
data_plot_up <- data_plot_up %>% gather(key = "years",value = "t_AUC",X1,X3,X5,X8)


data_plot$time_from <- as.numeric(data_plot$time_from)
data_plot_low$time_from <- as.numeric(data_plot_low$time_from)
data_plot_up$time_from <- as.numeric(data_plot_up$time_from)

data_plot_low$low <- data_plot_low$t_AUC
data_plot_up$up <- data_plot_up$t_AUC
up <- data_plot_up$up
data_CI <- cbind(data_plot_low, up)

data_plot$years <- factor(data_plot$years)
data_CI$years <- factor(data_CI$years)

p1 <- ggplot(data_plot, aes(x = time_from, y = t_AUC)) +
  geom_line(aes(colour = years, linetype = years),size = 1.8) + 
  xlab("age at prediction scoring") + 
  ylab("AUC ROC") +
  scale_x_continuous(breaks = seq(0,7)) +
  scale_y_continuous(breaks = seq(0.5,1,0.1),limits = c(0.5,1)) +
  scale_colour_brewer(palette = "Set1",name = "future prediction interval",
                        breaks = c("X1","X3","X5","X8"),
                        labels = c("1 year","3 years","5 years","8 years")) +
  scale_linetype_manual(name = "future prediction interval",
                        values = c("X1" = "solid","X3" = "twodash","X5" = "dashed","X8" = "dotted"),
                        labels = c("1 year","3 years","5 years","8 years")) +
  geom_ribbon(data = data_CI,aes(ymin = low,ymax = up,fill = years),alpha = 0.1,show.legend = FALSE, colour = "transparent") +
  # ggtitle("Fig 1. Time-dependent AUC in the Teddy database for\n several values of landmark age and horizon times") + 
  theme_bw() +
  theme(axis.text = element_text(size = 14),
        axis.title = element_text(size = 14),
        legend.position = c(0.8, 0.4),
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14),
        legend.key.width = unit(2.5,"cm"))
p2 <- add_sub(p1, "\n Fig 1. Time-dependent AUC ROC to predict T1D in TEDDY by landmark age and horizon time", hjust = 0.52)
p3 <- ggdraw(p2)


######## with points
data_plot$linetype <- 1
data_plot$linetype <- factor(data_plot$linetype)

legend_name <- "Future Prediction Interval (Horizon)"
p1 <- ggplot(data_plot, aes(x = time_from, y = t_AUC)) +
  geom_point(aes(colour = years, shape = years),size = 5) +
  geom_line(aes(colour = years,linetype = linetype),size = 0.5) + 
  xlab("Years of Age at Prediction Scoring (Landmark)") + 
  ylab("ROC AUC") +
  # coord_equal(ratio = 16.19) +
  scale_x_continuous(breaks = seq(0,7)) +
  scale_y_continuous(breaks = seq(0.60,1,0.1),limits = c(0.60,1)) +
  scale_linetype_manual(name = "Model Components",
                        values = "solid",
                        labels = c("AB+GRS2+FH")) +
  scale_colour_manual(name = legend_name,
                      values = c("#e41a1c","#4daf4a","#377eb8","#984ea3"),
                      breaks = c("X1","X3","X5","X8"),
                      labels = c("1 year","3 years","5 years","8 years")) +
  scale_shape_manual(name = legend_name,
                      values = (c(15,16,17,18)),
                      labels = c("1 year","3 years","5 years","8 years")) +
    geom_ribbon(data = data_CI,aes(ymin = low,ymax = up,fill = years),alpha = 0.1,show.legend = FALSE, colour = "transparent") +
  # ggtitle("Fig 1. Time-dependent AUC in the Teddy database for\n several values of landmark age and horizon times") + 
  theme_bw() +
  theme(axis.text = element_text(size = 14),
        axis.title = element_text(size = 14),
        legend.position = c(0.60, 0.3),
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14),
        legend.key.width = unit(0,"cm"),
        legend.key.height  = unit(1,"cm")) +
  geom_vline(xintercept = 2,linetype = "dashed") +
  guides(linetype = guide_legend(order = 1))
p1
# p2 <- add_sub(p1, "\n Fig 1. ROC AUC to predict T1D in TEDDY by landmark age and horizon time", hjust = 0.52)
# p3 <- ggdraw(p2)
# ggsave(paste0("C:/Users/Lauric/Desktop/Postdoc/t_AUC - GRS2/figures/t_AUC_plot_CI2",method,"_",complexity,".jpg"))
# 
# library("tidyverse")
# library("officer")
# library("rvg")
# read_pptx() %>%
#   add_slide(layout = "Title and Content", master = "Office Theme") %>%
#   ph_with_vg(code = print(p1), type = "body") %>% 
#   print(target = "C:/Users/Lauric/Desktop/adafigure4.pptx")
# 

### for power point
p2 <- ggplot(data_plot, aes(x = time_from, y = t_AUC)) +
  geom_point(aes(colour = years, shape = years),size = 5) +
  geom_line(aes(colour = years,linetype = linetype),size = 0.5) + 
  xlab("Years of Age at Prediction Scoring (Landmark)") + 
  ylab("ROC AUC") +
  # coord_equal(ratio = 16.19) +
  scale_x_continuous(breaks = seq(0,7)) +
  scale_y_continuous(breaks = seq(0.60,1,0.1),limits = c(0.60,1)) +
  scale_linetype_manual(name = "Model Components",
                        values = "solid",
                        labels = c("AB+GRS2+FH")) +
  scale_colour_manual(name = legend_name,
                      values = c("#e41a1c","#4daf4a","#377eb8","#984ea3"),
                      breaks = c("X1","X3","X5","X8"),
                      labels = c("1 year","3 years","5 years","8 years")) +
  scale_shape_manual(name = legend_name,
                     values = (c(15,16,17,18)),
                     labels = c("1 year","3 years","5 years","8 years")) +
  geom_ribbon(data = data_CI,aes(ymin = low,ymax = up,fill = years),alpha = 0.1,show.legend = FALSE, colour = "transparent") +
  # ggtitle("Fig 1. Time-dependent AUC in the Teddy database for\n several values of landmark age and horizon times") + 
  theme_bw() +
  theme(axis.text = element_text(size = 12),
        axis.title = element_text(size = 12),
        legend.position = c(0.60, 0.3),
        legend.text = element_text(size = 12),
        legend.title = element_text(size = 12),
        legend.key.width = unit(0,"cm"),
        legend.key.height  = unit(0.5,"cm")) +
  geom_vline(xintercept = 2,linetype = "dashed") +
  guides(linetype = guide_legend(order = 1))
p2


ggsave(paste0(pathfigures_tables,"figure2_new.jpg"),width = 6.8,scale = 1,height = 4)


read_pptx() %>%
  add_slide(layout = "Title and Content", master = "Office Theme") %>%
  ph_with_vg(code = print(p2), type = "body") %>%
  print(target = paste0(pathfigures_tables,"figure2_new.pptx"))
